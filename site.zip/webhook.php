<?php
/**
 * Recebe a confirmação de pagamento da LunarPay.
 *
 * Multi-usuário: esse endpoint é compartilhado por TODOS os gateways
 * hospedados aqui (é a mesma URL de callback pra todo mundo), então não
 * dá pra validar a assinatura antes de saber de quem é o pedido — cada
 * usuário tem sua própria chave. Por isso a ordem aqui é: 1) acha o
 * pedido pelo external_id, 2) descobre o dono, 3) só então valida a
 * assinatura com a chave DESSE dono. Ver aprenda.php da LunarPay, etapa 4,
 * pra entender o esquema de assinatura em si.
 */
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/telegram.php';

$rawBody         = file_get_contents('php://input');
$signatureHeader = $_SERVER['HTTP_X_LUNARPAY_SIGNATURE'] ?? '';

$payload    = json_decode($rawBody, true) ?: [];
$externalId = (string) ($payload['external_id'] ?? '');
$status     = (string) ($payload['status'] ?? '');

if ($externalId === '') {
    http_response_code(200);
    exit('ok');
}

$pdo = db();
$stmt = $pdo->prepare("SELECT * FROM orders WHERE external_id = ?");
$stmt->execute([$externalId]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    // Pedido que a LunarPay conhece mas que não existe aqui (ex: teste
    // manual). Responde 200 pra LunarPay não ficar reenviando à toa.
    http_response_code(200);
    exit('pedido desconhecido');
}

$ownerStmt = $pdo->prepare("SELECT lunarpay_api_key FROM users WHERE id = ?");
$ownerStmt->execute([$order['user_id']]);
$apiKey = (string) $ownerStmt->fetchColumn();

if ($apiKey === '') {
    http_response_code(500);
    exit('Gateway sem chave da LunarPay configurada.');
}

$expected = 'sha256=' . hash_hmac('sha256', $rawBody, $apiKey);
if ($signatureHeader === '' || !hash_equals($expected, $signatureHeader)) {
    http_response_code(401);
    exit('Assinatura inválida.');
}

if ($order['status'] === 'pending' && $status === 'paid') {
    // O "AND status = 'pending'" garante idempotência: se a LunarPay
    // reenviar o mesmo webhook duas vezes, a segunda vez não faz nada.
    $upd = $pdo->prepare(
        "UPDATE orders SET status = 'paid', paid_at = datetime('now')
         WHERE external_id = ? AND status = 'pending'"
    );
    $upd->execute([$externalId]);

    if ($upd->rowCount() > 0) {
        telegram_notify_sale(
            (int) $order['user_id'],
            (string) ($order['product_name'] ?: 'Produto Digital'),
            (float) $order['amount'],
            (string) ($order['customer_name'] ?? '')
        );

        // Baixa de estoque só na confirmação do pagamento (nunca na hora de
        // gerar o Pix — senão um Pix nunca pago travaria estoque à toa).
        if ($order['product_id']) {
            $pdo->prepare("UPDATE products SET stock = stock - 1 WHERE id = ? AND stock IS NOT NULL AND stock > 0")
                ->execute([(int) $order['product_id']]);
        }
    }

    // ── Aqui é o lugar de liberar o produto/acesso do seu cliente ──
    // Exemplos: enviar e-mail com o link de download, liberar acesso
    // num grupo, chamar outra API sua, etc.
}

http_response_code(200);
echo 'ok';
