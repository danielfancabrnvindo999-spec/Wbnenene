import * as React from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { api, type Me } from '@/lib/api'

const AuthCtx = React.createContext<{
  me: Me | undefined
  isLoading: boolean
  refetch: () => void
} | null>(null)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const query = useQuery({
    queryKey: ['me'],
    queryFn: () => api.get<Me>('/api/me.php'),
    retry: false,
  })
  return (
    <AuthCtx.Provider value={{ me: query.data, isLoading: query.isLoading, refetch: query.refetch }}>
      {children}
    </AuthCtx.Provider>
  )
}

export function useAuth() {
  const ctx = React.useContext(AuthCtx)
  if (!ctx) throw new Error('useAuth precisa estar dentro de <AuthProvider>')
  return ctx
}

export function useLogout() {
  const qc = useQueryClient()
  return async () => {
    await api.post('/api/logout.php')
    qc.setQueryData(['me'], undefined)
    window.location.href = '/admin/app/login'
  }
}
