import { NavLink } from 'react-router-dom'
import {
  LayoutDashboard,
  QrCode,
  Receipt,
  ArrowLeftRight,
  Package,
  Ticket,
  Settings,
  UserCog,
  Users,
  Activity,
  LogOut,
  Landmark,
  Percent,
  KeyRound,
  LayoutGrid,
  BadgeCheck,
} from 'lucide-react'
import { useAuth, useLogout } from '@/hooks/useAuth'
import { cn } from '@/lib/utils'

const mainItems = [
  { to: '/', label: 'Início', icon: LayoutDashboard, end: true },
  { to: '/gerar-pix', label: 'Gerar Pix', icon: QrCode, badge: 'NOVO' },
  { to: '/boleto', label: 'Gerar boleto', icon: Receipt, badge: 'NOVO' },
  { to: '/vendas', label: 'Extrato & Vendas', icon: ArrowLeftRight },
]

const manageItems = [
  { to: '/produtos', label: 'Produtos', icon: Package },
  { to: '/cupons', label: 'Cupons', icon: Ticket },
  { to: '/settings', label: 'Configurações', icon: Settings },
  { to: '/conta', label: 'Usuário & Senha', icon: UserCog },
]

const financeItems = [
  { to: '/saque', label: 'Saque', icon: Landmark },
  { to: '/taxas', label: 'Taxas & Rotas', icon: Percent },
  { to: '/api', label: 'API', icon: KeyRound },
]

const ownerItems = [
  { to: '/dashboard-geral', label: 'Dashboard geral', icon: LayoutGrid },
  { to: '/usuarios', label: 'Usuários', icon: Users },
  { to: '/saques-admin', label: 'Aprovar saques', icon: BadgeCheck },
  { to: '/auditoria', label: 'Auditoria', icon: Activity },
]

function Item({ to, label, icon: Icon, end, badge }: { to: string; label: string; icon: any; end?: boolean; badge?: string }) {
  return (
    <NavLink
      to={to}
      end={end}
      className={({ isActive }) =>
        cn(
          'group flex items-center justify-between rounded-lg px-3 py-2.5 text-sm font-medium text-muted transition-colors',
          isActive ? 'bg-white text-black' : 'hover:bg-surface-2 hover:text-foreground',
        )
      }
    >
      <span className="flex items-center gap-3">
        <Icon className="h-[18px] w-[18px]" strokeWidth={2} />
        {label}
      </span>
      {badge && <span className="rounded-full bg-success px-1.5 py-0.5 text-[10px] font-extrabold text-black">{badge}</span>}
    </NavLink>
  )
}

export function Sidebar({ open }: { open: boolean }) {
  const { me } = useAuth()
  const logout = useLogout()
  const initial = (me?.username?.[0] || 'A').toUpperCase()

  return (
    <aside
      className={cn(
        'fixed inset-y-0 left-0 z-40 flex w-[260px] flex-col gap-1 border-r border-border-subtle bg-surface-1 p-4 backdrop-blur-2xl transition-transform duration-[var(--motion-normal)]',
        open ? 'translate-x-0' : '-translate-x-full lg:translate-x-0',
      )}
    >
      <NavLink to="/" className="mb-6 flex items-center gap-3 px-1 py-1">
        <div className="flex h-9 w-9 items-center justify-center rounded-full bg-white text-sm font-extrabold text-black">
          {initial}
        </div>
        <div className="min-w-0">
          <div className="truncate text-sm font-semibold">{me?.username}</div>
          <div className="truncate text-xs text-muted-foreground">{me?.site_name}</div>
        </div>
      </NavLink>

      <nav className="flex flex-1 flex-col gap-1 overflow-y-auto">
        {mainItems.map((i) => <Item key={i.to} {...i} />)}

        <div className="mb-1 mt-4 px-3 text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
          Gestão & Vender
        </div>
        {manageItems.map((i) => <Item key={i.to} {...i} />)}

        <div className="mb-1 mt-4 px-3 text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
          Financeiro & Dev
        </div>
        {financeItems.map((i) => <Item key={i.to} {...i} />)}

        {me?.is_owner && (
          <>
            <div className="mb-1 mt-4 px-3 text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
              Sistema
            </div>
            {ownerItems.map((i) => <Item key={i.to} {...i} />)}
          </>
        )}
      </nav>

      <button
        onClick={logout}
        className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-danger transition-colors hover:bg-danger/10"
      >
        <LogOut className="h-[18px] w-[18px]" />
        Sair da Conta
      </button>
    </aside>
  )
}
