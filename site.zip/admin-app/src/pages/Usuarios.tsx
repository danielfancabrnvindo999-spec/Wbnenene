import * as React from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { Users, Search, KeyRound, Landmark } from 'lucide-react'
import { Card, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { EmptyState } from '@/components/ui/empty-state'
import { Skeleton } from '@/components/ui/skeleton'
import { CopyButton } from '@/components/ui/copy-button'
import { ConfirmDialog } from '@/components/ui/confirm-dialog'
import { api, ApiError } from '@/lib/api'
import { formatBRL, formatDateTime } from '@/lib/utils'
import { useAuth } from '@/hooks/useAuth'

interface UsersResponse {
  totals: { total: number; active: number }
  users: {
    id: number
    username: string
    site_name: string
    active: boolean
    nominal: string
    created_at: string
    has_api_key: boolean
    orders_count: number
    volume: number
  }[]
}

export default function Usuarios() {
  const { me } = useAuth()
  const qc = useQueryClient()
  const [search, setSearch] = React.useState('')
  const [toReset, setToReset] = React.useState<UsersResponse['users'][number] | null>(null)
  const [tempPassword, setTempPassword] = React.useState<{ username: string; password: string } | null>(null)

  const { data, isLoading } = useQuery({
    queryKey: ['usuarios', search],
    queryFn: () => api.get<UsersResponse>(`/api/usuarios.php?q=${encodeURIComponent(search)}`),
  })

  const toggleMutation = useMutation({
    mutationFn: (id: number) => api.postCsrf('/api/usuarios.php', { user_id: id, action: 'toggle' }, me!.csrf),
    onSuccess: () => {
      toast.success('Status atualizado.')
      qc.invalidateQueries({ queryKey: ['usuarios'] })
    },
    onError: () => toast.error('Não foi possível atualizar o status agora.'),
  })

  const resetPasswordMutation = useMutation({
    mutationFn: (id: number) => api.postCsrf<{ ok: boolean; temp_password: string }>('/api/usuarios.php', { user_id: id, action: 'reset_password' }, me!.csrf),
    onSuccess: (res) => {
      if (toReset) setTempPassword({ username: toReset.username, password: res.temp_password })
      setToReset(null)
    },
    onError: (e) => {
      toast.error(e instanceof ApiError ? e.message : 'Não foi possível redefinir a senha.')
      setToReset(null)
    },
  })

  const signupUrl = `${window.location.origin}/admin/app/registro`

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-bold">Usuários da plataforma</h1>
        <p className="text-sm text-muted">Controle acesso sem visualizar senhas ou chaves privadas.</p>
      </div>

      <Card>
        <CardTitle>Link de cadastro</CardTitle>
        <p className="mb-3 text-sm text-muted">Mande esse link pra quem você quer convidar — a pessoa cria o próprio gateway sozinha, isolado dos demais.</p>
        <div className="flex flex-wrap items-center gap-2">
          <code className="flex-1 truncate rounded-md bg-surface-2 px-3 py-2 text-xs text-muted">{signupUrl}</code>
          <CopyButton value={signupUrl} />
        </div>
      </Card>

      {data && (
        <div className="grid grid-cols-3 gap-4">
          <Card><p className="text-sm text-muted">Cadastros</p><p className="mt-1 text-2xl font-bold">{data.totals.total}</p></Card>
          <Card><p className="text-sm text-muted">Ativos</p><p className="mt-1 text-2xl font-bold">{data.totals.active}</p></Card>
          <Card><p className="text-sm text-muted">Suspensos</p><p className="mt-1 text-2xl font-bold">{data.totals.total - data.totals.active}</p></Card>
        </div>
      )}

      <div className="relative max-w-sm">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input className="pl-9" placeholder="Buscar usuário ou gateway" value={search} onChange={(e) => setSearch(e.target.value)} />
      </div>

      <Card>
        {isLoading ? (
          <div className="flex flex-col gap-2">{[...Array(4)].map((_, i) => <Skeleton key={i} className="h-14 w-full" />)}</div>
        ) : !data || data.users.length === 0 ? (
          <EmptyState icon={Users} title="Nenhum usuário encontrado" description="Ajuste a busca ou aguarde novos cadastros." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs uppercase tracking-wide text-muted-foreground">
                  <th className="pb-3 font-medium">Usuário</th>
                  <th className="pb-3 font-medium">Gateway</th>
                  <th className="pb-3 font-medium">Rota</th>
                  <th className="pb-3 font-medium">Vendas</th>
                  <th className="pb-3 font-medium">Volume</th>
                  <th className="pb-3 font-medium">Status</th>
                  <th className="pb-3 text-right font-medium">Ação</th>
                </tr>
              </thead>
              <tbody>
                {data.users.map((u) => (
                  <tr key={u.id} className="border-t border-border-subtle">
                    <td className="py-3 pr-3">
                      <p className="font-medium">{u.username}</p>
                      <p className="text-xs text-muted-foreground">{formatDateTime(u.created_at)}</p>
                    </td>
                    <td className="py-3 pr-3">
                      <p>{u.site_name}</p>
                      <p className="text-xs text-muted-foreground">{u.has_api_key ? 'API configurada' : 'API pendente'}</p>
                    </td>
                    <td className="py-3 pr-3 text-xs text-muted">{u.nominal}</td>
                    <td className="py-3 pr-3">{u.orders_count}</td>
                    <td className="py-3 pr-3 font-semibold tabular-nums">{formatBRL(u.volume)}</td>
                    <td className="py-3 pr-3"><Badge status={u.active ? 'success' : 'neutral'}>{u.active ? 'Ativo' : 'Suspenso'}</Badge></td>
                    <td className="py-3 text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          aria-label="Ver saques do membro"
                          title="Ver saques do membro"
                          onClick={() => window.location.assign(`/admin/app/saques-admin?status=all`)}
                        >
                          <Landmark className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          aria-label="Redefinir senha"
                          title="Redefinir senha"
                          onClick={() => setToReset(u)}
                        >
                          <KeyRound className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="w-auto"
                          loading={toggleMutation.isPending && toggleMutation.variables === u.id}
                          onClick={() => toggleMutation.mutate(u.id)}
                        >
                          {u.active ? 'Suspender' : 'Reativar'}
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <ConfirmDialog
        open={!!toReset}
        onOpenChange={(o) => !o && setToReset(null)}
        title="Redefinir senha do membro?"
        description={`Uma senha temporária nova é gerada pra "${toReset?.username}" e a senha atual dele para de funcionar imediatamente. Você vai precisar repassar a senha nova pra ele.`}
        confirmLabel="Redefinir senha"
        destructive
        loading={resetPasswordMutation.isPending}
        onConfirm={() => toReset && resetPasswordMutation.mutate(toReset.id)}
      />

      <ConfirmDialog
        open={!!tempPassword}
        onOpenChange={(o) => !o && setTempPassword(null)}
        title="Senha temporária gerada"
        description={`Repasse pra "${tempPassword?.username}" agora — essa senha não aparece de novo depois de fechar esta janela.`}
        confirmLabel="Copiar e fechar"
        onConfirm={() => {
          if (tempPassword) navigator.clipboard?.writeText(tempPassword.password).catch(() => {})
          setTempPassword(null)
        }}
      >
        <code className="block w-full rounded-md bg-surface-2 px-3 py-2 text-center text-sm font-semibold tracking-wide">
          {tempPassword?.password}
        </code>
      </ConfirmDialog>
    </div>
  )
}
