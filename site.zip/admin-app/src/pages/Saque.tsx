import * as React from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { ExternalLink, Landmark, ArrowRight, Clock } from 'lucide-react'
import { Card, CardTitle, CardHeader } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input, Label, FieldError } from '@/components/ui/input'
import { CurrencyInput } from '@/components/ui/currency-input'
import { Badge } from '@/components/ui/badge'
import { ConfirmDialog } from '@/components/ui/confirm-dialog'
import { Skeleton } from '@/components/ui/skeleton'
import { EmptyState } from '@/components/ui/empty-state'
import { api, ApiError } from '@/lib/api'
import { formatBRL, formatDateTime } from '@/lib/utils'
import { useAuth } from '@/hooks/useAuth'

interface BalanceResponse {
  currency: string
  available: number
  pending: number
}

interface WithdrawalRequest {
  id: number
  amount: number
  pix_key: string
  pix_key_type: string
  status: 'pending' | 'approved' | 'rejected' | 'failed'
  reject_reason: string | null
  lunarpay_withdrawal_id: string | null
  created_at: string
  reviewed_at: string | null
}

const KEY_TYPES = [
  { value: 'cpf', label: 'CPF' },
  { value: 'cnpj', label: 'CNPJ' },
  { value: 'email', label: 'E-mail' },
  { value: 'phone', label: 'Telefone' },
  { value: 'random', label: 'Chave aleatória' },
]

const STATUS_LABEL: Record<WithdrawalRequest['status'], { label: string; status: 'success' | 'danger' | 'warning' }> = {
  pending: { label: 'Aguardando aprovação', status: 'warning' },
  approved: { label: 'Aprovado e enviado', status: 'success' },
  rejected: { label: 'Rejeitado', status: 'danger' },
  failed: { label: 'Falhou na LunarPay', status: 'danger' },
}

export default function Saque() {
  const { me } = useAuth()
  const qc = useQueryClient()
  const [amountCents, setAmountCents] = React.useState(0)
  const [pixKey, setPixKey] = React.useState('')
  const [pixKeyType, setPixKeyType] = React.useState('cpf')
  const [confirmOpen, setConfirmOpen] = React.useState(false)
  const [error, setError] = React.useState('')

  const { data: balance, isLoading: loadingBalance, isError: balanceError, error: balanceErrorObj } = useQuery({
    queryKey: ['balance'],
    queryFn: () => api.get<BalanceResponse>('/api/balance.php'),
    retry: false,
  })

  const { data: requests, isLoading: loadingRequests } = useQuery({
    queryKey: ['withdraw-requests'],
    queryFn: () => api.get<WithdrawalRequest[]>('/api/withdraw.php'),
  })

  const withdrawMutation = useMutation({
    mutationFn: () =>
      api.postCsrf<WithdrawalRequest>(
        '/api/withdraw.php',
        { amount: amountCents / 100, pix_key: pixKey, pix_key_type: pixKeyType },
        me!.csrf,
      ),
    onSuccess: () => {
      setConfirmOpen(false)
      setError('')
      setAmountCents(0)
      setPixKey('')
      qc.invalidateQueries({ queryKey: ['withdraw-requests'] })
      toast.success('Pedido de saque enviado — aguardando aprovação do administrador.')
    },
    onError: (e) => {
      const message = e instanceof ApiError ? e.message : 'Não foi possível solicitar o saque.'
      setError(message)
      setConfirmOpen(false)
      toast.error(message)
    },
  })

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-bold">Saque</h1>
        <p className="text-sm text-muted">Todo saque passa pela aprovação do administrador antes do dinheiro sair de verdade.</p>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Card>
          <CardTitle>Disponível</CardTitle>
          {loadingBalance ? <Skeleton className="mt-2 h-9 w-32" /> : (
            <div className="mt-1 text-2xl font-bold tabular-nums">{formatBRL(balance?.available ?? 0)}</div>
          )}
        </Card>
        <Card>
          <CardTitle>Em compensação</CardTitle>
          {loadingBalance ? <Skeleton className="mt-2 h-9 w-32" /> : (
            <div className="mt-1 text-2xl font-bold tabular-nums">{formatBRL(balance?.pending ?? 0)}</div>
          )}
        </Card>
      </div>

      {balanceError && (
        <div className="rounded-xl border border-danger/30 bg-danger/10 px-4 py-3 text-sm text-danger">
          {balanceErrorObj instanceof ApiError ? balanceErrorObj.message : 'Não foi possível consultar seu saldo agora.'}
        </div>
      )}

      <Card>
        <CardTitle>Solicitar saque</CardTitle>
        <form
          onSubmit={(e) => {
            e.preventDefault()
            setConfirmOpen(true)
          }}
        >
          <Label htmlFor="amount">Valor</Label>
          <CurrencyInput id="amount" valueCents={amountCents} onValueChange={setAmountCents} required />

          <div className="mt-4">
            <Label htmlFor="pix_key_type">Tipo de chave Pix</Label>
            <select
              id="pix_key_type"
              value={pixKeyType}
              onChange={(e) => setPixKeyType(e.target.value)}
              className="h-11 w-full rounded-md border border-border-subtle bg-surface-1 px-3.5 text-sm text-foreground focus:border-border-active focus:outline-none"
            >
              {KEY_TYPES.map((k) => <option key={k.value} value={k.value}>{k.label}</option>)}
            </select>
          </div>

          <div className="mt-4">
            <Label htmlFor="pix_key">Chave Pix de destino</Label>
            <Input id="pix_key" value={pixKey} onChange={(e) => setPixKey(e.target.value)} required />
          </div>

          <FieldError>{error}</FieldError>

          <Button type="submit" size="checkout" className="mt-6" disabled={amountCents === 0 || !pixKey}>
            Solicitar saque <ArrowRight className="h-4 w-4" />
          </Button>
        </form>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Histórico de pedidos</CardTitle>
        </CardHeader>
        {loadingRequests ? (
          <div className="flex flex-col gap-2">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-14 w-full" />)}</div>
        ) : !requests || requests.length === 0 ? (
          <EmptyState icon={Clock} title="Nenhum pedido de saque ainda" description="Quando você solicitar um saque, ele aparece aqui." />
        ) : (
          <div className="flex flex-col gap-2">
            {requests.map((r) => (
              <div key={r.id} className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border-subtle px-4 py-3">
                <div>
                  <p className="font-semibold tabular-nums">{formatBRL(r.amount)}</p>
                  <p className="text-xs text-muted-foreground">{formatDateTime(r.created_at)} · {r.pix_key}</p>
                  {r.status === 'rejected' && r.reject_reason && <p className="mt-1 text-xs text-danger">{r.reject_reason}</p>}
                  {r.status === 'failed' && r.reject_reason && <p className="mt-1 text-xs text-danger">{r.reject_reason}</p>}
                </div>
                <Badge status={STATUS_LABEL[r.status].status}>{STATUS_LABEL[r.status].label}</Badge>
              </div>
            ))}
          </div>
        )}
      </Card>

      <Card>
        <div className="flex items-start gap-4">
          <div className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-surface-2">
            <Landmark className="h-5 w-5" />
          </div>
          <div>
            <p className="text-sm text-muted">
              Se o administrador aprovar e ainda assim der erro dizendo que "saque via API está desativado", peça pra ele ativar em{' '}
              <a href="https://lunarpay.site" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 font-semibold underline">
                lunarpay.site <ExternalLink className="h-3 w-3" />
              </a>{' '}
              → Configurações → Desenvolvedor / API, na conta LunarPay do membro.
            </p>
          </div>
        </div>
      </Card>

      <ConfirmDialog
        open={confirmOpen}
        onOpenChange={setConfirmOpen}
        title="Confirmar pedido de saque?"
        description={`${formatBRL(amountCents / 100)} via Pix (${KEY_TYPES.find((k) => k.value === pixKeyType)?.label}: ${pixKey}). O pedido fica pendente até o administrador aprovar — nenhum dinheiro sai agora.`}
        confirmLabel="Enviar pedido"
        loading={withdrawMutation.isPending}
        onConfirm={() => withdrawMutation.mutate()}
      />
    </div>
  )
}
