import * as React from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { Card, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input, Label, FieldError } from '@/components/ui/input'
import { Skeleton } from '@/components/ui/skeleton'
import { api, ApiError } from '@/lib/api'
import { useAuth } from '@/hooks/useAuth'

interface SettingsData {
  site_name: string
  has_api_key: boolean
  has_telegram_bot: boolean
  has_telegram_chat: boolean
  nominal: string
}

export default function Settings() {
  const { me, refetch: refetchMe } = useAuth()
  const qc = useQueryClient()
  const [error, setError] = React.useState('')
  const { data, isLoading } = useQuery({
    queryKey: ['settings'],
    queryFn: () => api.get<SettingsData>('/api/settings.php'),
  })

  const mutation = useMutation({
    mutationFn: (form: Record<string, unknown>) => api.postCsrf('/api/settings.php', form, me!.csrf),
    onSuccess: () => {
      toast.success('Configurações salvas.')
      setError('')
      qc.invalidateQueries({ queryKey: ['settings'] })
      refetchMe()
    },
    onError: (e) => setError(e instanceof ApiError ? e.message : 'Falha ao salvar.'),
  })

  if (isLoading || !data) {
    return <div className="grid gap-4 lg:grid-cols-3">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-64" />)}</div>
  }

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const form = new FormData(e.currentTarget)
    mutation.mutate({
      site_name: form.get('site_name'),
      lunarpay_api_key: form.get('lunarpay_api_key'),
      nominal: form.get('nominal'),
      telegram_bot_token: form.get('telegram_bot_token'),
      telegram_chat_id: form.get('telegram_chat_id'),
      clear_telegram: form.get('clear_telegram') === 'on',
    })
  }

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-bold">Configurações do gateway</h1>
        <p className="text-sm text-muted">Identidade, processamento e notificações em um só lugar.</p>
      </div>

      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <div className="grid gap-4 lg:grid-cols-3">
          <Card>
            <CardTitle>IDENTIDADE</CardTitle>
            <h2 className="mb-3 font-semibold">Marca do checkout</h2>
            <Label htmlFor="site_name">Nome público</Label>
            <Input id="site_name" name="site_name" maxLength={80} defaultValue={data.site_name} required />
            <p className="mt-2 text-xs text-muted-foreground">Aparece no checkout e nos links de pagamento.</p>
          </Card>

          <Card>
            <CardTitle>LUNARPAY</CardTitle>
            <h2 className="mb-3 font-semibold">Processamento</h2>
            <Label htmlFor="lunarpay_api_key">Ghost Key</Label>
            <Input
              id="lunarpay_api_key"
              name="lunarpay_api_key"
              type="password"
              autoComplete="new-password"
              placeholder={data.has_api_key ? 'Deixe vazio para manter a chave atual' : 'ghost_...'}
            />
            <div className="mt-3">
              <Label htmlFor="nominal">Rota</Label>
              <select
                id="nominal"
                name="nominal"
                defaultValue={data.nominal}
                className="h-11 w-full rounded-md border border-border-subtle bg-surface-1 px-3.5 text-sm text-foreground focus:border-border-active focus:outline-none"
              >
                <option value="nominal1">Nominal 1 · reembolso automático</option>
                <option value="nominal3">Nominal 3</option>
                <option value="nominal7">Nominal 7</option>
              </select>
            </div>
            <p className="mt-2 text-xs text-muted-foreground">A chave nunca é exibida novamente. A troca de rota é confirmada pela API.</p>
          </Card>

          <Card>
            <CardTitle>ALERTAS</CardTitle>
            <h2 className="mb-3 font-semibold">Telegram</h2>
            <Label htmlFor="telegram_bot_token">Novo token do bot</Label>
            <Input
              id="telegram_bot_token"
              name="telegram_bot_token"
              type="password"
              autoComplete="new-password"
              placeholder={data.has_telegram_bot ? 'Configurado · deixe vazio para manter' : 'Cole o token do BotFather'}
            />
            <div className="mt-3">
              <Label htmlFor="telegram_chat_id">Novo Chat ID</Label>
              <Input id="telegram_chat_id" name="telegram_chat_id" placeholder={data.has_telegram_chat ? 'Configurado · deixe vazio para manter' : 'ID numérico do chat'} />
            </div>
            <label className="mt-3 flex items-center gap-2 text-sm text-muted">
              <input type="checkbox" name="clear_telegram" className="h-4 w-4 rounded border-border-subtle" />
              Remover integração atual
            </label>
          </Card>
        </div>

        <FieldError>{error}</FieldError>

        <Button type="submit" className="w-auto" loading={mutation.isPending}>Salvar alterações</Button>
      </form>
    </div>
  )
}
