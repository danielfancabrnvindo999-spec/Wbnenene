import * as React from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { Package, Trash2, ImageOff } from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input, Label, FieldError } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { CopyButton } from '@/components/ui/copy-button'
import { EmptyState } from '@/components/ui/empty-state'
import { Skeleton } from '@/components/ui/skeleton'
import { ConfirmDialog } from '@/components/ui/confirm-dialog'
import { api, ApiError } from '@/lib/api'
import { formatBRL } from '@/lib/utils'
import { useAuth } from '@/hooks/useAuth'

interface Product {
  id: number
  slug: string
  name: string
  description: string | null
  price: number
  image_path: string | null
  stock: number | null
  redirect_url: string | null
  active: boolean
  link: string
}

export default function Produtos() {
  const { me } = useAuth()
  const qc = useQueryClient()
  const [error, setError] = React.useState('')
  const [editingId, setEditingId] = React.useState<number | null>(null)
  const [toDelete, setToDelete] = React.useState<Product | null>(null)
  const formRef = React.useRef<HTMLFormElement>(null)

  const { data, isLoading } = useQuery({
    queryKey: ['produtos'],
    queryFn: () => api.get<Product[]>('/api/produtos.php'),
  })

  const invalidate = () => qc.invalidateQueries({ queryKey: ['produtos'] })

  const createMutation = useMutation({
    mutationFn: (form: FormData) => api.postMultipart('/api/produtos.php', form, me!.csrf),
    onSuccess: () => {
      toast.success('Produto criado! O link já está pronto na lista abaixo.')
      formRef.current?.reset()
      setError('')
      invalidate()
    },
    onError: (e) => setError(e instanceof ApiError ? e.message : 'Falha ao criar produto.'),
  })

  const updateMutation = useMutation({
    mutationFn: (form: FormData) => api.postMultipart('/api/produtos.php', form, me!.csrf),
    onSuccess: () => {
      toast.success('Produto atualizado.')
      setEditingId(null)
      invalidate()
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Falha ao atualizar.'),
  })

  const toggleMutation = useMutation({
    mutationFn: (id: number) => api.postCsrf('/api/produtos.php', { action: 'toggle', id }, me!.csrf),
    onSuccess: invalidate,
    onError: (e) => {
      toast.error(e instanceof ApiError ? e.message : 'Não foi possível atualizar o produto.')
      invalidate()
    },
  })

  const deleteMutation = useMutation({
    mutationFn: (id: number) => api.postCsrf('/api/produtos.php', { action: 'delete', id }, me!.csrf),
    onSuccess: () => {
      toast.success('Produto removido. Links já compartilhados param de funcionar.')
      setToDelete(null)
      invalidate()
    },
    onError: (e) => {
      toast.error(e instanceof ApiError ? e.message : 'Não foi possível remover o produto.')
      setToDelete(null)
      invalidate()
    },
  })

  function handleCreate(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const form = new FormData(e.currentTarget)
    form.set('action', 'create')
    createMutation.mutate(form)
  }

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-bold">Produtos e links de pagamento</h1>
        <p className="text-sm text-muted">
          Cadastre um produto uma vez e ganhe um link fixo pra compartilhar (WhatsApp, bio do Instagram, etc.).
        </p>
      </div>

      <Card className="max-w-xl">
        <p className="mb-4 font-semibold">Novo produto</p>
        <form ref={formRef} onSubmit={handleCreate} encType="multipart/form-data">
          <Label htmlFor="name">Nome do produto</Label>
          <Input id="name" name="name" maxLength={120} required />

          <div className="mt-4">
            <Label htmlFor="price">Valor (R$)</Label>
            <Input id="price" name="price" type="number" min={5} step="0.01" required />
          </div>

          <div className="mt-4">
            <Label htmlFor="description">Descrição (opcional)</Label>
            <Input id="description" name="description" maxLength={200} />
          </div>

          <div className="mt-4">
            <Label htmlFor="image">Imagem de capa (opcional, JPG/PNG/WEBP até 3 MB)</Label>
            <input id="image" name="image" type="file" accept="image/jpeg,image/png,image/webp,image/gif" className="block w-full text-sm text-muted file:mr-3 file:rounded-md file:border-0 file:bg-surface-2 file:px-3 file:py-2 file:text-sm file:font-medium file:text-foreground" />
          </div>

          <div className="mt-4">
            <Label htmlFor="stock">Estoque (em branco = ilimitado)</Label>
            <Input id="stock" name="stock" type="number" min={0} placeholder="Ilimitado" />
          </div>

          <div className="mt-4">
            <Label htmlFor="redirect_url">Link após o pagamento (opcional)</Label>
            <Input id="redirect_url" name="redirect_url" type="url" placeholder="https://..." maxLength={300} />
          </div>

          <FieldError>{error}</FieldError>

          <Button type="submit" className="mt-5" loading={createMutation.isPending}>Gerar link de pagamento</Button>
        </form>
      </Card>

      <Card>
        <p className="mb-4 font-semibold">Seus produtos</p>
        {isLoading ? (
          <div className="flex flex-col gap-2">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-24 w-full" />)}</div>
        ) : !data || data.length === 0 ? (
          <EmptyState icon={Package} title="Nenhum produto cadastrado" description="Crie o primeiro acima para gerar seu link de pagamento fixo." />
        ) : (
          <div className="flex flex-col gap-4">
            {data.map((p) => (
              <div key={p.id} className="rounded-lg border border-border-subtle p-4">
                <div className="flex flex-wrap items-start gap-4">
                  {p.image_path ? (
                    <img src={`/${p.image_path}`} alt="" className="h-16 w-16 rounded-md object-cover" />
                  ) : (
                    <div className="grid h-16 w-16 shrink-0 place-items-center rounded-md bg-surface-2 text-muted-foreground">
                      <ImageOff className="h-6 w-6" />
                    </div>
                  )}
                  <div className="min-w-[200px] flex-1">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <strong>{p.name}</strong>
                        <span className="text-muted">— {formatBRL(p.price)}</span>
                        <Badge status={p.active ? 'success' : 'neutral'}>{p.active ? 'Ativo' : 'Desativado'}</Badge>
                        {p.stock !== null && (
                          <Badge status={p.stock <= 0 ? 'danger' : 'neutral'}>
                            {p.stock <= 0 ? 'Esgotado' : `${p.stock} em estoque`}
                          </Badge>
                        )}
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" className="w-auto" onClick={() => setEditingId(editingId === p.id ? null : p.id)}>
                          Editar
                        </Button>
                        <Button variant="outline" size="sm" className="w-auto" onClick={() => toggleMutation.mutate(p.id)} loading={toggleMutation.isPending && toggleMutation.variables === p.id}>
                          {p.active ? 'Desativar' : 'Ativar'}
                        </Button>
                        <Button variant="ghost" size="icon" aria-label="Remover produto" title="Remover produto" onClick={() => setToDelete(p)}>
                          <Trash2 className="h-4 w-4 text-danger" />
                        </Button>
                      </div>
                    </div>
                    {p.description && <p className="mt-2 text-sm text-muted">{p.description}</p>}
                    <div className="mt-3 flex items-center gap-2">
                      <code className="flex-1 truncate rounded-md bg-surface-2 px-3 py-1.5 text-xs text-muted">{p.link}</code>
                      <CopyButton value={p.link} />
                    </div>
                  </div>
                </div>

                {editingId === p.id && (
                  <form
                    className="mt-4 border-t border-border-subtle pt-4"
                    encType="multipart/form-data"
                    onSubmit={(e) => {
                      e.preventDefault()
                      const form = new FormData(e.currentTarget)
                      form.set('action', 'update')
                      form.set('id', String(p.id))
                      updateMutation.mutate(form)
                    }}
                  >
                    <Label>Valor (R$)</Label>
                    <Input name="price" type="number" min={5} step="0.01" defaultValue={p.price} required />
                    <div className="mt-3">
                      <Label>Descrição</Label>
                      <Input name="description" maxLength={200} defaultValue={p.description ?? ''} />
                    </div>
                    <div className="mt-3">
                      <Label>Trocar imagem de capa</Label>
                      <input name="image" type="file" accept="image/jpeg,image/png,image/webp,image/gif" className="block w-full text-sm text-muted file:mr-3 file:rounded-md file:border-0 file:bg-surface-2 file:px-3 file:py-2 file:text-sm file:font-medium file:text-foreground" />
                    </div>
                    <div className="mt-3">
                      <Label>Estoque (em branco = ilimitado)</Label>
                      <Input name="stock" type="number" min={0} defaultValue={p.stock ?? ''} placeholder="Ilimitado" />
                    </div>
                    <div className="mt-3">
                      <Label>Link após o pagamento</Label>
                      <Input name="redirect_url" type="url" maxLength={300} defaultValue={p.redirect_url ?? ''} placeholder="https://..." />
                    </div>
                    <Button type="submit" size="sm" className="mt-4 w-auto" loading={updateMutation.isPending}>Salvar alterações</Button>
                  </form>
                )}
              </div>
            ))}
          </div>
        )}
      </Card>

      <ConfirmDialog
        open={!!toDelete}
        onOpenChange={(o) => !o && setToDelete(null)}
        title="Remover produto?"
        description={`Links já compartilhados de "${toDelete?.name}" param de funcionar imediatamente.`}
        confirmLabel="Remover"
        destructive
        loading={deleteMutation.isPending}
        onConfirm={() => toDelete && deleteMutation.mutate(toDelete.id)}
      />
    </div>
  )
}
