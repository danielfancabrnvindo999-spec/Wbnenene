import { useQuery } from '@tanstack/react-query'
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis } from 'recharts'
import { Users, TrendingUp, Receipt, Landmark, type LucideIcon } from 'lucide-react'
import { Card, CardHeader, CardTitle } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { EmptyState } from '@/components/ui/empty-state'
import { api } from '@/lib/api'
import { formatBRL } from '@/lib/utils'

interface DashboardAdminData {
  membros_total: number
  membros_ativos: number
  volume_total: number
  vendas_total: number
  volume_hoje: number
  vendas_hoje: number
  pedidos_pendentes: number
  saques_pendentes: number
  week: { label: string; date: string; total: number }[]
  top_membros: { id: number; username: string; site_name: string; vendas: number; volume: number }[]
}

export default function DashboardAdmin() {
  const { data, isLoading } = useQuery({
    queryKey: ['dashboard-admin'],
    queryFn: () => api.get<DashboardAdminData>('/api/dashboard_admin.php'),
  })

  if (isLoading || !data) {
    return (
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Skeleton className="h-[220px] lg:col-span-2" />
        <Skeleton className="h-[220px]" />
        <Skeleton className="h-[100px]" />
        <Skeleton className="h-[100px]" />
        <Skeleton className="h-[100px]" />
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-bold">Visão geral da plataforma</h1>
        <p className="text-sm text-muted">Soma de todos os membros — não só a sua conta.</p>
      </div>

      {data.saques_pendentes > 0 && (
        <a
          href="/admin/app/saques-admin"
          className="rounded-xl border border-warning/30 bg-warning/10 px-4 py-3 text-sm text-warning transition-colors hover:bg-warning/20"
        >
          {data.saques_pendentes} pedido(s) de saque aguardando sua aprovação →
        </a>
      )}

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card className="glass lg:col-span-2">
          <CardTitle>Volume total da plataforma</CardTitle>
          <div className="mt-2 text-4xl font-bold tabular-nums">{formatBRL(data.volume_total)}</div>
          <p className="mt-1 text-sm text-muted">{data.vendas_total} venda(s) pagas, todo o período</p>

          <div className="mt-6 h-[120px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data.week}>
                <defs>
                  <linearGradient id="fillAdmin" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#ffffff" stopOpacity={0.25} />
                    <stop offset="100%" stopColor="#ffffff" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="label" axisLine={false} tickLine={false} tick={{ fill: 'var(--muted-foreground)', fontSize: 12 }} />
                <Tooltip
                  contentStyle={{ background: '#141416', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 10, fontSize: 12 }}
                  labelStyle={{ color: '#a3a3a3' }}
                  formatter={(v) => [formatBRL(Number(v)), 'Faturamento']}
                />
                <Area type="monotone" dataKey="total" stroke="#f5f5f5" strokeWidth={2} fill="url(#fillAdmin)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card>
          <CardTitle>Recebido hoje</CardTitle>
          <div className="mt-2 text-2xl font-bold tabular-nums">{formatBRL(data.volume_hoje)}</div>
          <p className="mt-1 text-xs text-muted">{data.vendas_hoje} venda(s) hoje</p>
        </Card>

        <StatCard icon={Users} label="Membros ativos" value={`${data.membros_ativos} / ${data.membros_total}`} />
        <StatCard icon={Receipt} label="Pedidos pendentes" value={String(data.pedidos_pendentes)} />
        <StatCard icon={Landmark} label="Saques aguardando aprovação" value={String(data.saques_pendentes)} />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Top membros por volume</CardTitle>
        </CardHeader>
        {data.top_membros.length === 0 ? (
          <EmptyState icon={TrendingUp} title="Nenhum membro com vendas ainda" description="Quando os membros começarem a vender, o ranking aparece aqui." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs uppercase tracking-wide text-muted-foreground">
                  <th className="pb-3 font-medium">Membro</th>
                  <th className="pb-3 font-medium">Vendas</th>
                  <th className="pb-3 text-right font-medium">Volume</th>
                </tr>
              </thead>
              <tbody>
                {data.top_membros.map((m) => (
                  <tr key={m.id} className="border-t border-border-subtle">
                    <td className="py-3 pr-3">
                      <p className="font-medium">{m.username}</p>
                      <p className="text-xs text-muted-foreground">{m.site_name}</p>
                    </td>
                    <td className="py-3 pr-3">{m.vendas}</td>
                    <td className="py-3 text-right font-semibold tabular-nums">{formatBRL(m.volume)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  )
}

function StatCard({ icon: Icon, label, value }: { icon: LucideIcon; label: string; value: string }) {
  return (
    <Card>
      <div className="flex items-center gap-2 text-muted">
        <Icon className="h-4 w-4" />
        <span className="text-sm">{label}</span>
      </div>
      <div className="mt-2 text-2xl font-bold tabular-nums">{value}</div>
    </Card>
  )
}
