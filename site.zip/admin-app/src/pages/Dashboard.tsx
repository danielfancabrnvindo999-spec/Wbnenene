import { useQuery } from '@tanstack/react-query'
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis } from 'recharts'
import { TrendingUp, Receipt, Percent, CheckCircle2, Circle, ArrowUpRight, type LucideIcon } from 'lucide-react'
import { Card, CardHeader, CardTitle } from '@/components/ui/card'
import { CopyButton } from '@/components/ui/copy-button'
import { StatusBadge } from '@/components/ui/status-badge'
import { Skeleton } from '@/components/ui/skeleton'
import { EmptyState } from '@/components/ui/empty-state'
import { api } from '@/lib/api'
import { formatBRL, formatDateTime } from '@/lib/utils'
import { useAuth } from '@/hooks/useAuth'

interface DashboardData {
  site_name: string
  saldo: number
  hoje_valor: number
  hoje_vendas: number
  volume_mes: number
  pendentes: number
  total_pedidos: number
  total_pagos: number
  pct_pago: number
  checklist: { done: boolean; title: string; desc: string; href: string }[]
  week: { label: string; date: string; total: number }[]
  public_checkout_url: string
  orders: {
    id: number
    external_id: string
    amount: number
    product_name: string | null
    customer_name: string | null
    status: string
    payment_method: string
    created_at: string
  }[]
}

export default function Dashboard() {
  const { me } = useAuth()
  const { data, isLoading } = useQuery({
    queryKey: ['dashboard'],
    queryFn: () => api.get<DashboardData>('/api/dashboard.php'),
  })

  if (isLoading || !data) return <DashboardSkeleton />

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-bold">Olá, {me?.username} 👋</h1>
        <p className="text-sm text-muted">Aqui está o resumo do seu gateway hoje.</p>
      </div>

      {!me?.has_api_key && (
        <div className="rounded-xl border border-warning/30 bg-warning/10 px-4 py-3 text-sm text-warning">
          Você ainda não cadastrou sua chave da LunarPay — nenhum Pix real será gerado até lá.{' '}
          <a href="/admin/app/settings" className="font-semibold underline">Cadastrar agora</a>
        </div>
      )}

      {/* Bento grid principal */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card className="glass lg:col-span-2 lg:row-span-1">
          <CardTitle>Saldo disponível</CardTitle>
          <div className="mt-2 flex items-end gap-3">
            <span className="text-4xl font-bold tabular-nums">{formatBRL(data.saldo)}</span>
          </div>
          <p className="mt-1 text-sm text-muted">Total já recebido, todo o período</p>

          <div className="mt-6 h-[120px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data.week}>
                <defs>
                  <linearGradient id="fill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#ffffff" stopOpacity={0.25} />
                    <stop offset="100%" stopColor="#ffffff" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="label" axisLine={false} tickLine={false} tick={{ fill: 'var(--muted-foreground)', fontSize: 12 }} />
                <Tooltip
                  contentStyle={{ background: '#141416', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 10, fontSize: 12 }}
                  labelStyle={{ color: '#a3a3a3' }}
                  formatter={(v) => [formatBRL(Number(v)), 'Faturamento']}
                />
                <Area type="monotone" dataKey="total" stroke="#f5f5f5" strokeWidth={2} fill="url(#fill)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card>
          <CardTitle>Recebido hoje</CardTitle>
          <div className="mt-2 text-2xl font-bold tabular-nums">{formatBRL(data.hoje_valor)}</div>
          <p className="mt-1 text-xs text-muted">{data.hoje_vendas} venda(s) hoje</p>
        </Card>

        <StatCard icon={TrendingUp} label="Faturamento no mês" value={formatBRL(data.volume_mes)} />
        <StatCard icon={Receipt} label="Pedidos pendentes" value={String(data.pendentes)} />
        <StatCard icon={Percent} label="Taxa de aprovação" value={`${data.pct_pago}%`} />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Link de checkout público</CardTitle>
        </CardHeader>
        <div className="flex flex-wrap items-center gap-2">
          <code className="flex-1 truncate rounded-md bg-surface-2 px-3 py-2 text-xs text-muted">
            {data.public_checkout_url}
          </code>
          <CopyButton value={data.public_checkout_url} />
        </div>
      </Card>

      {data.checklist.some((c) => !c.done) && (
        <Card>
          <CardHeader>
            <CardTitle>Primeiros passos</CardTitle>
          </CardHeader>
          <div className="flex flex-col gap-3">
            {data.checklist.map((c) => (
              <a
                key={c.title}
                href={`/admin/app${c.href}`}
                className="flex items-center gap-3 rounded-lg p-2 transition-colors hover:bg-surface-2"
              >
                {c.done ? (
                  <CheckCircle2 className="h-5 w-5 shrink-0 text-success" />
                ) : (
                  <Circle className="h-5 w-5 shrink-0 text-muted-foreground" />
                )}
                <div className="min-w-0">
                  <p className={c.done ? 'text-sm text-muted line-through' : 'text-sm font-medium'}>{c.title}</p>
                  <p className="text-xs text-muted-foreground">{c.desc}</p>
                </div>
              </a>
            ))}
          </div>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Transações recentes</CardTitle>
          <a href="/admin/app/vendas" className="flex items-center gap-1 text-sm font-medium text-foreground hover:underline">
            Ver todas <ArrowUpRight className="h-3.5 w-3.5" />
          </a>
        </CardHeader>

        {data.orders.length === 0 ? (
          <EmptyState
            icon={Receipt}
            title="Ainda não existem transações"
            description="Quando seu primeiro pagamento for confirmado, ele aparecerá aqui."
          />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <tbody>
                {data.orders.map((o) => (
                  <tr key={o.id} className="border-t border-border-subtle first:border-t-0">
                    <td className="py-3 pr-3">
                      <p className="font-medium">{o.product_name || 'Valor livre'}</p>
                      <p className="text-xs text-muted-foreground">{o.customer_name || o.external_id}</p>
                    </td>
                    <td className="py-3 pr-3 text-xs text-muted">{formatDateTime(o.created_at)}</td>
                    <td className="py-3 pr-3"><StatusBadge status={o.status} /></td>
                    <td className="py-3 text-right font-semibold tabular-nums">{formatBRL(o.amount)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  )
}

function StatCard({ icon: Icon, label, value }: { icon: LucideIcon; label: string; value: string }) {
  return (
    <Card>
      <div className="flex items-center gap-2 text-muted">
        <Icon className="h-4 w-4" />
        <span className="text-sm">{label}</span>
      </div>
      <div className="mt-2 text-2xl font-bold tabular-nums">{value}</div>
    </Card>
  )
}

function DashboardSkeleton() {
  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
      <Skeleton className="h-[220px] lg:col-span-2" />
      <Skeleton className="h-[220px]" />
      <Skeleton className="h-[100px]" />
      <Skeleton className="h-[100px]" />
      <Skeleton className="h-[100px]" />
    </div>
  )
}
