import * as React from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { Ticket, Trash2 } from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input, Label, FieldError } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { EmptyState } from '@/components/ui/empty-state'
import { Skeleton } from '@/components/ui/skeleton'
import { ConfirmDialog } from '@/components/ui/confirm-dialog'
import { api, ApiError } from '@/lib/api'
import { useAuth } from '@/hooks/useAuth'

interface Coupon {
  id: number
  code: string
  percent_off: number
  active: boolean
  uses: number
}

export default function Cupons() {
  const { me } = useAuth()
  const qc = useQueryClient()
  const [code, setCode] = React.useState('')
  const [percent, setPercent] = React.useState('10')
  const [error, setError] = React.useState('')
  const [toDelete, setToDelete] = React.useState<Coupon | null>(null)

  const { data, isLoading } = useQuery({
    queryKey: ['cupons'],
    queryFn: () => api.get<Coupon[]>('/api/cupons.php'),
  })

  const invalidate = () => qc.invalidateQueries({ queryKey: ['cupons'] })

  const createMutation = useMutation({
    mutationFn: () => api.postCsrf('/api/cupons.php', { action: 'create', code, percent_off: Number(percent) }, me!.csrf),
    onSuccess: () => {
      toast.success('Cupom criado! Já pode ser usado no checkout.')
      setCode('')
      setPercent('10')
      setError('')
      invalidate()
    },
    onError: (e) => setError(e instanceof ApiError ? e.message : 'Falha ao criar cupom.'),
  })

  const toggleMutation = useMutation({
    mutationFn: (id: number) => api.postCsrf('/api/cupons.php', { action: 'toggle', id }, me!.csrf),
    onSuccess: invalidate,
    onError: (e) => {
      toast.error(e instanceof ApiError ? e.message : 'Não foi possível atualizar o cupom.')
      invalidate()
    },
  })

  const deleteMutation = useMutation({
    mutationFn: (id: number) => api.postCsrf('/api/cupons.php', { action: 'delete', id }, me!.csrf),
    onSuccess: () => {
      toast.success('Cupom removido.')
      setToDelete(null)
      invalidate()
    },
    onError: (e) => {
      toast.error(e instanceof ApiError ? e.message : 'Não foi possível remover o cupom.')
      setToDelete(null)
      invalidate()
    },
  })

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-bold">Cupons de desconto</h1>
        <p className="text-sm text-muted">O desconto é sempre recalculado no servidor — o cliente nunca consegue burlar o valor.</p>
      </div>

      <Card className="max-w-md">
        <p className="mb-4 font-semibold">Novo cupom</p>
        <form
          onSubmit={(e) => {
            e.preventDefault()
            createMutation.mutate()
          }}
        >
          <Label htmlFor="code">Código (o cliente vai digitar isso)</Label>
          <Input
            id="code"
            className="uppercase"
            placeholder="BEMVINDO10"
            value={code}
            onChange={(e) => setCode(e.target.value.toUpperCase())}
            maxLength={40}
            required
          />

          <div className="mt-4">
            <Label htmlFor="percent">Desconto (%)</Label>
            <Input id="percent" type="number" min={1} max={90} value={percent} onChange={(e) => setPercent(e.target.value)} required />
          </div>

          <FieldError>{error}</FieldError>

          <Button type="submit" className="mt-5" loading={createMutation.isPending}>Criar cupom</Button>
        </form>
      </Card>

      <Card>
        <p className="mb-4 font-semibold">Seus cupons</p>
        {isLoading ? (
          <div className="flex flex-col gap-2">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-14 w-full" />)}</div>
        ) : !data || data.length === 0 ? (
          <EmptyState icon={Ticket} title="Nenhum cupom cadastrado" description="Crie um código acima para dar desconto no checkout." />
        ) : (
          <div className="flex flex-col gap-2">
            {data.map((c) => (
              <div key={c.id} className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border-subtle px-4 py-3">
                <div className="flex items-center gap-3">
                  <span className="font-mono text-sm font-semibold">{c.code}</span>
                  <span className="text-sm text-muted">{c.percent_off}% off</span>
                  <Badge status={c.active ? 'success' : 'neutral'}>{c.active ? 'Ativo' : 'Desativado'}</Badge>
                  <span className="text-xs text-muted-foreground">{c.uses} uso(s)</span>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="w-auto" onClick={() => toggleMutation.mutate(c.id)} loading={toggleMutation.isPending && toggleMutation.variables === c.id}>
                    {c.active ? 'Desativar' : 'Ativar'}
                  </Button>
                  <Button variant="ghost" size="icon" aria-label="Remover cupom" title="Remover cupom" onClick={() => setToDelete(c)}>
                    <Trash2 className="h-4 w-4 text-danger" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      <ConfirmDialog
        open={!!toDelete}
        onOpenChange={(o) => !o && setToDelete(null)}
        title="Remover cupom?"
        description={`O código "${toDelete?.code}" deixará de funcionar no checkout imediatamente.`}
        confirmLabel="Remover"
        destructive
        loading={deleteMutation.isPending}
        onConfirm={() => toDelete && deleteMutation.mutate(toDelete.id)}
      />
    </div>
  )
}
