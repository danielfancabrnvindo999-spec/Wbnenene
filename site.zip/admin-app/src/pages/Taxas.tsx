import { useQuery } from '@tanstack/react-query'
import { Badge } from '@/components/ui/badge'
import { Card, CardTitle } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { EmptyState } from '@/components/ui/empty-state'
import { Percent } from 'lucide-react'
import { api, ApiError } from '@/lib/api'

interface SettingsData {
  nominal: string
}

interface FeeInfo {
  fee_percent: number
  fee_fixed: number
  auto_payout: boolean
  refund_automatic: boolean
}

interface FeesResponse {
  fees: Record<string, FeeInfo>
}

const ROUTE_NAMES: Record<string, string> = {
  nominal1: 'Nominal 1',
  nominal3: 'Nominal 3',
  nominal7: 'Nominal 7',
}

export default function Taxas() {
  const { data: settings } = useQuery({
    queryKey: ['settings'],
    queryFn: () => api.get<SettingsData>('/api/settings.php'),
  })

  const { data: fees, isLoading, isError, error } = useQuery({
    queryKey: ['fees'],
    queryFn: () => api.get<FeesResponse>('/api/fees.php'),
    retry: false,
  })

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-bold">Taxas & rotas de processamento</h1>
        <p className="text-sm text-muted">Taxa vigente na sua conta LunarPay, direto da fonte — atualiza se a LunarPay mudar sua tarifa.</p>
      </div>

      <Card>
        <CardTitle>Suas rotas</CardTitle>
        {isLoading ? (
          <div className="mt-2 flex flex-col gap-3">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-20 w-full" />)}</div>
        ) : isError ? (
          <EmptyState
            icon={Percent}
            title="Não foi possível consultar as taxas"
            description={error instanceof ApiError ? error.message : 'Tente novamente em alguns segundos.'}
          />
        ) : (
          <div className="mt-2 flex flex-col gap-3">
            {Object.entries(fees?.fees ?? {}).map(([nominal, f]) => (
              <div key={nominal} className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border-subtle px-4 py-3">
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <strong>{ROUTE_NAMES[nominal] ?? nominal}</strong>
                    {settings?.nominal === nominal && <Badge status="success">Sua rota atual</Badge>}
                    <Badge status={f.refund_automatic ? 'success' : 'neutral'}>
                      {f.refund_automatic ? 'Reembolso automático' : 'Sem reembolso automático'}
                    </Badge>
                    <Badge status={f.auto_payout ? 'success' : 'neutral'}>
                      {f.auto_payout ? 'Repasse automático' : 'Repasse manual'}
                    </Badge>
                  </div>
                  <p className="mt-1 text-sm text-muted">
                    {f.fee_percent}% + {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(f.fee_fixed)} por transação
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
        <p className="mt-4 text-sm text-muted">
          Pra trocar de rota, vá em <a href="/admin/app/settings" className="font-semibold underline">Configurações</a>.
        </p>
      </Card>
    </div>
  )
}
