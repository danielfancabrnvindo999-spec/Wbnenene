import { Navigate, Link, useNavigate } from 'react-router-dom'
import { zodResolver } from '@hookform/resolvers/zod'
import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input, Label, FieldError } from '@/components/ui/input'
import { api, ApiError } from '@/lib/api'
import { useAuth } from '@/hooks/useAuth'

const schema = z.object({
  username: z.string().min(1, 'Informe o usuário'),
  password: z.string().min(1, 'Informe a senha'),
})
type FormValues = z.infer<typeof schema>

export default function Login() {
  const navigate = useNavigate()
  const { me, isLoading, refetch } = useAuth()
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
    setError,
  } = useForm<FormValues>({ resolver: zodResolver(schema) })

  async function onSubmit(values: FormValues) {
    try {
      await api.post('/api/login.php', values)
      await refetch()
      navigate('/', { replace: true })
    } catch (e) {
      if (e instanceof ApiError && e.message === 'setup_required') {
        window.location.href = '/admin/setup.php'
        return
      }
      const message = e instanceof ApiError ? e.message : 'Não foi possível entrar.'
      setError('root', { message })
      toast.error(message)
    }
  }

  if (!isLoading && me) return <Navigate to="/" replace />

  return (
    <div className="flex min-h-screen items-center justify-center px-4">
      <div className="w-full max-w-sm">
        <div className="mb-8 flex flex-col items-center gap-3 text-center">
          <div className="flex h-14 w-14 items-center justify-center rounded-full bg-white text-lg font-extrabold text-black shadow-[0_0_30px_rgba(255,255,255,0.15)]">
            G
          </div>
          <div>
            <h1 className="text-xl font-bold">Painel administrativo</h1>
            <p className="text-sm text-muted">Entre para gerenciar seu gateway</p>
          </div>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="glass rounded-2xl p-6" noValidate>
          <Label htmlFor="username">Usuário</Label>
          <Input id="username" autoComplete="username" aria-invalid={!!errors.username} {...register('username')} />
          <FieldError>{errors.username?.message}</FieldError>

          <div className="mt-4">
            <Label htmlFor="password">Senha</Label>
            <Input id="password" type="password" autoComplete="current-password" aria-invalid={!!errors.password} {...register('password')} />
            <FieldError>{errors.password?.message}</FieldError>
          </div>

          {errors.root && (
            <p className="mt-4 rounded-md border border-danger/30 bg-danger/10 px-3 py-2 text-sm text-danger">
              {errors.root.message}
            </p>
          )}

          <Button type="submit" size="checkout" loading={isSubmitting} className="mt-6">
            Entrar
          </Button>

          <Link to="/registro" className="mt-4 block text-center text-sm text-muted hover:text-foreground hover:underline">
            Criar conta
          </Link>
        </form>
      </div>
    </div>
  )
}
