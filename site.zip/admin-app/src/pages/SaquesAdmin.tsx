import * as React from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { Landmark, Check, X } from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { EmptyState } from '@/components/ui/empty-state'
import { Skeleton } from '@/components/ui/skeleton'
import { ConfirmDialog } from '@/components/ui/confirm-dialog'
import { api, ApiError } from '@/lib/api'
import { formatBRL, formatDateTime } from '@/lib/utils'
import { useAuth } from '@/hooks/useAuth'

interface AdminWithdrawal {
  id: number
  user_id: number
  username: string
  site_name: string
  amount: number
  pix_key: string
  pix_key_type: string
  status: 'pending' | 'approved' | 'rejected' | 'failed'
  reject_reason: string | null
  lunarpay_withdrawal_id: string | null
  created_at: string
  reviewed_at: string | null
}

interface AdminWithdrawalsResponse {
  pendentes: number
  saques: AdminWithdrawal[]
}

const FILTERS = [
  { value: 'pending', label: 'Pendentes' },
  { value: 'approved', label: 'Aprovados' },
  { value: 'rejected', label: 'Rejeitados' },
  { value: 'failed', label: 'Falharam' },
  { value: 'all', label: 'Todos' },
]

const STATUS_BADGE: Record<AdminWithdrawal['status'], 'success' | 'danger' | 'warning'> = {
  pending: 'warning',
  approved: 'success',
  rejected: 'danger',
  failed: 'danger',
}

export default function SaquesAdmin() {
  const { me } = useAuth()
  const qc = useQueryClient()
  const [status, setStatus] = React.useState(() => new URLSearchParams(window.location.search).get('status') || 'pending')
  const [toApprove, setToApprove] = React.useState<AdminWithdrawal | null>(null)
  const [toReject, setToReject] = React.useState<AdminWithdrawal | null>(null)
  const [reason, setReason] = React.useState('')

  const { data, isLoading } = useQuery({
    queryKey: ['saques-admin', status],
    queryFn: () => api.get<AdminWithdrawalsResponse>(`/api/saques_admin.php?status=${status}`),
  })

  const invalidate = () => qc.invalidateQueries({ queryKey: ['saques-admin'] })

  const approveMutation = useMutation({
    mutationFn: (id: number) => api.postCsrf('/api/saques_admin.php', { id, action: 'approve' }, me!.csrf),
    onSuccess: () => {
      toast.success('Saque aprovado e enviado pra LunarPay.')
      setToApprove(null)
      invalidate()
    },
    onError: (e) => {
      toast.error(e instanceof ApiError ? e.message : 'Não foi possível aprovar o saque.')
      setToApprove(null)
      invalidate()
    },
  })

  const rejectMutation = useMutation({
    mutationFn: (vars: { id: number; reason: string }) =>
      api.postCsrf('/api/saques_admin.php', { id: vars.id, action: 'reject', reason: vars.reason }, me!.csrf),
    onSuccess: () => {
      toast.success('Saque rejeitado.')
      setToReject(null)
      setReason('')
      invalidate()
    },
    onError: (e) => {
      toast.error(e instanceof ApiError ? e.message : 'Não foi possível rejeitar o saque.')
      setToReject(null)
      invalidate()
    },
  })

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-bold">Aprovar saques</h1>
        <p className="text-sm text-muted">
          Aprovar dispara o saque de verdade na conta LunarPay do próprio membro — você não movimenta dinheiro da sua conta, só autoriza o pedido dele.
        </p>
      </div>

      <div className="flex flex-wrap gap-2">
        {FILTERS.map((f) => (
          <button
            key={f.value}
            onClick={() => setStatus(f.value)}
            className={`rounded-full border px-3 py-1.5 text-xs font-medium transition-colors ${status === f.value ? 'border-white bg-white text-black' : 'border-border-subtle text-muted hover:border-border-hover'}`}
          >
            {f.label}{f.value === 'pending' && data ? ` · ${data.pendentes}` : ''}
          </button>
        ))}
      </div>

      <Card>
        {isLoading ? (
          <div className="flex flex-col gap-2">{[...Array(4)].map((_, i) => <Skeleton key={i} className="h-16 w-full" />)}</div>
        ) : !data || data.saques.length === 0 ? (
          <EmptyState icon={Landmark} title="Nenhum pedido de saque" description="Pedidos de saque dos membros aparecem aqui." />
        ) : (
          <div className="flex flex-col gap-2">
            {data.saques.map((s) => (
              <div key={s.id} className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border-subtle px-4 py-3">
                <div className="min-w-[220px]">
                  <div className="flex items-center gap-2">
                    <p className="font-semibold">{s.username}</p>
                    <span className="text-xs text-muted-foreground">{s.site_name}</span>
                  </div>
                  <p className="mt-1 text-lg font-bold tabular-nums">{formatBRL(s.amount)}</p>
                  <p className="text-xs text-muted-foreground">
                    {s.pix_key_type.toUpperCase()}: {s.pix_key} · {formatDateTime(s.created_at)}
                  </p>
                  {s.reject_reason && <p className="mt-1 text-xs text-danger">{s.reject_reason}</p>}
                </div>
                <div className="flex items-center gap-2">
                  <Badge status={STATUS_BADGE[s.status]}>{s.status}</Badge>
                  {s.status === 'pending' && (
                    <>
                      <Button variant="outline" size="sm" className="w-auto" onClick={() => setToReject(s)}>
                        <X className="h-4 w-4 text-danger" /> Rejeitar
                      </Button>
                      <Button size="sm" className="w-auto" onClick={() => setToApprove(s)}>
                        <Check className="h-4 w-4" /> Aprovar
                      </Button>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      <ConfirmDialog
        open={!!toApprove}
        onOpenChange={(o) => !o && setToApprove(null)}
        title="Aprovar saque?"
        description={`${formatBRL(toApprove?.amount ?? 0)} sai agora de verdade da conta LunarPay de ${toApprove?.username} pra chave ${toApprove?.pix_key}. Não pode ser desfeito.`}
        confirmLabel="Aprovar e enviar"
        destructive
        loading={approveMutation.isPending}
        onConfirm={() => toApprove && approveMutation.mutate(toApprove.id)}
      />

      <ConfirmDialog
        open={!!toReject}
        onOpenChange={(o) => { if (!o) { setToReject(null); setReason('') } }}
        title="Rejeitar saque?"
        description={`O pedido de ${formatBRL(toReject?.amount ?? 0)} de ${toReject?.username} não será enviado à LunarPay.`}
        confirmLabel="Rejeitar"
        destructive
        loading={rejectMutation.isPending}
        onConfirm={() => toReject && rejectMutation.mutate({ id: toReject.id, reason })}
      >
        <textarea
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          placeholder="Motivo (opcional)"
          rows={2}
          className="w-full rounded-md border border-border-subtle bg-surface-1 px-3 py-2 text-sm text-foreground focus:border-border-active focus:outline-none"
        />
      </ConfirmDialog>
    </div>
  )
}
