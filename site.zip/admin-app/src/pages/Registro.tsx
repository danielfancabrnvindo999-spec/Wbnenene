import { Navigate, Link, useNavigate } from 'react-router-dom'
import { zodResolver } from '@hookform/resolvers/zod'
import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input, Label, FieldError } from '@/components/ui/input'
import { api, ApiError } from '@/lib/api'
import { useAuth } from '@/hooks/useAuth'

const schema = z
  .object({
    username: z.string().regex(/^[a-z0-9_.-]{3,30}$/, 'Use de 3 a 30 letras minúsculas, números, pontos, hífens ou sublinhados.'),
    site_name: z.string().min(1, 'Informe o nome da sua loja.'),
    pass: z.string().min(12, 'A senha precisa ter pelo menos 12 caracteres.'),
    pass2: z.string(),
  })
  .refine((v) => v.pass === v.pass2, { message: 'As senhas não são iguais.', path: ['pass2'] })
type FormValues = z.infer<typeof schema>

export default function Registro() {
  const navigate = useNavigate()
  const { me, isLoading, refetch } = useAuth()
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
    setError,
  } = useForm<FormValues>({ resolver: zodResolver(schema) })

  if (!isLoading && me) return <Navigate to="/" replace />

  async function onSubmit(values: FormValues) {
    try {
      await api.post('/api/registro.php', values)
      await refetch()
      navigate('/', { replace: true })
    } catch (e) {
      if (e instanceof ApiError && e.message === 'setup_required') {
        window.location.href = '/admin/setup.php'
        return
      }
      const message = e instanceof ApiError ? e.message : 'Não foi possível criar a conta.'
      setError('root', { message })
      toast.error(message)
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center px-4">
      <div className="w-full max-w-sm">
        <div className="mb-8 flex flex-col items-center gap-3 text-center">
          <div className="flex h-14 w-14 items-center justify-center rounded-full bg-white text-lg font-extrabold text-black shadow-[0_0_30px_rgba(255,255,255,0.15)]">
            G
          </div>
          <div>
            <h1 className="text-xl font-bold">Criar conta</h1>
            <p className="text-sm text-muted">Crie sua conta de vendedor nesta plataforma</p>
          </div>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="glass rounded-2xl p-6" noValidate>
          <Label htmlFor="username">Usuário</Label>
          <Input id="username" autoComplete="username" placeholder="seuusuario" aria-invalid={!!errors.username} {...register('username')} />
          <FieldError>{errors.username?.message}</FieldError>

          <div className="mt-4">
            <Label htmlFor="site_name">Nome da sua loja</Label>
            <Input id="site_name" placeholder="Minha Loja" aria-invalid={!!errors.site_name} {...register('site_name')} />
            <FieldError>{errors.site_name?.message}</FieldError>
          </div>

          <div className="mt-4">
            <Label htmlFor="pass">Senha (mínimo 12 caracteres)</Label>
            <Input id="pass" type="password" autoComplete="new-password" aria-invalid={!!errors.pass} {...register('pass')} />
            <FieldError>{errors.pass?.message}</FieldError>
          </div>

          <div className="mt-4">
            <Label htmlFor="pass2">Confirme a senha</Label>
            <Input id="pass2" type="password" autoComplete="new-password" aria-invalid={!!errors.pass2} {...register('pass2')} />
            <FieldError>{errors.pass2?.message}</FieldError>
          </div>

          {errors.root && (
            <p className="mt-4 rounded-md border border-danger/30 bg-danger/10 px-3 py-2 text-sm text-danger">
              {errors.root.message}
            </p>
          )}

          <Button type="submit" size="checkout" loading={isSubmitting} className="mt-6">
            Criar conta
          </Button>

          <Link to="/login" className="mt-4 block text-center text-sm text-muted hover:text-foreground hover:underline">
            Voltar ao login
          </Link>
        </form>
      </div>
    </div>
  )
}
