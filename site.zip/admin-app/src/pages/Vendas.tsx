import * as React from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { RefreshCw, Undo2, Receipt } from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { StatusBadge } from '@/components/ui/status-badge'
import { Skeleton } from '@/components/ui/skeleton'
import { EmptyState } from '@/components/ui/empty-state'
import { ConfirmDialog } from '@/components/ui/confirm-dialog'
import { api } from '@/lib/api'
import { formatBRL, formatDateTime } from '@/lib/utils'
import { useAuth } from '@/hooks/useAuth'

interface Order {
  id: number
  external_id: string
  amount: number
  product_name: string | null
  customer_name: string | null
  status: string
  payment_method: string
  created_at: string
}

const FILTERS = [
  { value: 'todos', label: 'Todos' },
  { value: 'pago', label: 'Pagos' },
  { value: 'pendente', label: 'Pendentes' },
  { value: 'reembolsado', label: 'Reembolsados' },
]

export default function Vendas() {
  const [filter, setFilter] = React.useState('todos')
  const [toRefund, setToRefund] = React.useState<Order | null>(null)
  const { me } = useAuth()
  const qc = useQueryClient()

  const { data, isLoading } = useQuery({
    queryKey: ['vendas', filter],
    queryFn: () => api.get<Order[]>(`/api/vendas.php?status=${filter}`),
  })

  const checkMutation = useMutation({
    mutationFn: (id: number) => api.postForm(`/check_order.php`, { id: String(id), csrf: me!.csrf }),
    onSuccess: () => {
      toast.success('Status verificado.')
      qc.invalidateQueries({ queryKey: ['vendas'] })
    },
    onError: () => toast.error('Não foi possível verificar agora.'),
  })

  const refundMutation = useMutation({
    mutationFn: (id: number) => api.postForm(`/refund_order.php`, { id: String(id), csrf: me!.csrf }),
    onSuccess: () => {
      toast.success('Reembolso solicitado.')
      setToRefund(null)
      qc.invalidateQueries({ queryKey: ['vendas'] })
    },
    onError: () => toast.error('Não foi possível reembolsar.'),
  })

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Extrato & Vendas</h1>
          <p className="text-sm text-muted">Últimos 200 pedidos.</p>
        </div>
        <div className="flex gap-1 rounded-lg border border-border-subtle bg-surface-1 p-1">
          {FILTERS.map((f) => (
            <button
              key={f.value}
              onClick={() => setFilter(f.value)}
              className={`rounded-md px-3 py-1.5 text-sm font-medium transition-colors ${
                filter === f.value ? 'bg-white text-black' : 'text-muted hover:text-foreground'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      <Card>
        {isLoading ? (
          <div className="flex flex-col gap-2">
            {[...Array(5)].map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}
          </div>
        ) : !data || data.length === 0 ? (
          <EmptyState icon={Receipt} title="Nenhuma venda encontrada" description="Ajuste o filtro ou aguarde novas vendas chegarem." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs uppercase tracking-wide text-muted-foreground">
                  <th className="pb-3 font-medium">Cliente / Produto</th>
                  <th className="pb-3 font-medium">Método</th>
                  <th className="pb-3 font-medium">Data</th>
                  <th className="pb-3 font-medium">Status</th>
                  <th className="pb-3 text-right font-medium">Valor</th>
                  <th className="pb-3 text-right font-medium">Ações</th>
                </tr>
              </thead>
              <tbody>
                {data.map((o) => (
                  <tr key={o.id} className="border-t border-border-subtle">
                    <td className="py-3 pr-3">
                      <p className="font-medium">{o.product_name || 'Valor livre'}</p>
                      <p className="text-xs text-muted-foreground">{o.customer_name || o.external_id}</p>
                    </td>
                    <td className="py-3 pr-3 text-xs uppercase text-muted">{o.payment_method}</td>
                    <td className="py-3 pr-3 text-xs text-muted">{formatDateTime(o.created_at)}</td>
                    <td className="py-3 pr-3"><StatusBadge status={o.status} /></td>
                    <td className="py-3 text-right font-semibold tabular-nums">{formatBRL(o.amount)}</td>
                    <td className="py-3 text-right">
                      <div className="flex justify-end gap-1.5">
                        {o.status === 'pending' && (
                          <Button
                            variant="ghost"
                            size="icon"
                            title="Verificar status"
                            loading={checkMutation.isPending && checkMutation.variables === o.id}
                            onClick={() => checkMutation.mutate(o.id)}
                          >
                            <RefreshCw className="h-4 w-4" />
                          </Button>
                        )}
                        {o.status === 'paid' && (
                          <Button
                            variant="ghost"
                            size="icon"
                            title="Reembolsar"
                            loading={refundMutation.isPending && refundMutation.variables === o.id}
                            onClick={() => setToRefund(o)}
                          >
                            <Undo2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <ConfirmDialog
        open={!!toRefund}
        onOpenChange={(o) => !o && setToRefund(null)}
        title="Reembolsar esta venda?"
        description={`${formatBRL(toRefund?.amount ?? 0)} — esta ação não poderá ser desfeita.`}
        confirmLabel="Reembolsar"
        destructive
        loading={refundMutation.isPending}
        onConfirm={() => toRefund && refundMutation.mutate(toRefund.id)}
      />
    </div>
  )
}
