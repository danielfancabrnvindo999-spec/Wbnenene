import * as React from 'react'
import { useMutation } from '@tanstack/react-query'
import { QrCode, ArrowLeft } from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input, Label, FieldError } from '@/components/ui/input'
import { CurrencyInput } from '@/components/ui/currency-input'
import { CopyButton } from '@/components/ui/copy-button'
import { api, ApiError } from '@/lib/api'
import { formatBRL } from '@/lib/utils'
import { toast } from 'sonner'

interface ChargeResponse {
  external_id: string
  qr_image: string
  pix_code: string
  amount: number
}

export default function GerarPix() {
  const [amountCents, setAmountCents] = React.useState(0)
  const [productName, setProductName] = React.useState('')
  const [result, setResult] = React.useState<ChargeResponse | null>(null)

  const mutation = useMutation({
    mutationFn: () =>
      api.postRoot<ChargeResponse>('/api/create_charge.php', {
        amount: amountCents / 100,
        product_name: productName || 'Produto',
      }),
    onSuccess: (data: ChargeResponse) => setResult(data),
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Falha ao gerar o Pix.'),
  })

  if (result) {
    return (
      <div className="mx-auto max-w-md">
        <Card className="glass text-center">
          <p className="text-xs font-semibold uppercase tracking-wider text-muted">Pix gerado</p>
          <h2 className="mt-1 text-2xl font-bold">{formatBRL(result.amount)}</h2>
          <img src={result.qr_image} alt="QR Code Pix" className="mx-auto my-5 h-56 w-56 rounded-lg bg-white p-2" />
          <Label className="text-left">Código copia e cola</Label>
          <div className="flex items-center gap-2">
            <code className="flex-1 truncate rounded-md bg-surface-2 px-3 py-2 text-xs text-muted">
              {result.pix_code}
            </code>
            <CopyButton value={result.pix_code} />
          </div>
          <Button variant="secondary" className="mt-6" onClick={() => { setResult(null); setAmountCents(0); setProductName('') }}>
            <ArrowLeft className="h-4 w-4" /> Gerar outro Pix
          </Button>
        </Card>
      </div>
    )
  }

  return (
    <div className="mx-auto max-w-md">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Gerar Pix manualmente</h1>
        <p className="text-sm text-muted">Cobre um cliente na hora, sem precisar cadastrar um produto fixo.</p>
      </div>

      <Card>
        <form
          onSubmit={(e) => {
            e.preventDefault()
            mutation.mutate()
          }}
        >
          <Label htmlFor="amount">Valor</Label>
          <CurrencyInput id="amount" valueCents={amountCents} onValueChange={setAmountCents} required />
          <FieldError>{amountCents > 0 && amountCents < 500 ? 'O valor mínimo é R$ 5,00.' : undefined}</FieldError>

          <div className="mt-4">
            <Label htmlFor="product_name">Descrição (opcional)</Label>
            <Input id="product_name" value={productName} onChange={(e) => setProductName(e.target.value)} />
          </div>

          <Button type="submit" size="checkout" className="mt-6" loading={mutation.isPending} disabled={amountCents < 500}>
            <QrCode className="h-4 w-4" /> Gerar Pix
          </Button>
        </form>
      </Card>
    </div>
  )
}
