// Absoluto de propósito: caminho relativo ("..") depende da URL atual da
// página ter barra final, o que não é garantido em SPA (React Router deixa
// "/admin/app" sem "/" na rota raiz) — já causou fetch pra URL errada
// (silenciosamente virava /api/... em vez de /admin/api/...).
const BASE = '/admin'

export class ApiError extends Error {
  status: number
  constructor(message: string, status: number) {
    super(message)
    this.status = status
  }
}

async function request<T>(path: string, init?: RequestInit, base: string = BASE): Promise<T> {
  const isFormData = init?.body instanceof FormData
  const defaultHeaders: Record<string, string> = isFormData ? {} : { 'Content-Type': 'application/json' }
  const res = await fetch(`${base}${path}`, {
    credentials: 'include',
    ...init,
    headers: { ...defaultHeaders, ...(init?.headers as Record<string, string> | undefined) },
  })
  const isJson = res.headers.get('content-type')?.includes('application/json')
  const data = isJson ? await res.json().catch(() => null) : null
  if (!res.ok) {
    throw new ApiError(data?.error || 'Erro inesperado. Tente novamente.', res.status)
  }
  return data as T
}

export const api = {
  get: <T>(path: string) => request<T>(path),
  post: <T>(path: string, body?: unknown) =>
    request<T>(path, { method: 'POST', body: body ? JSON.stringify(body) : undefined }),
  postForm: <T>(path: string, form: Record<string, string>) =>
    request<T>(path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams(form),
    }),
  /** POST JSON pros endpoints admin/api/* que exigem CSRF no header (check_csrf_header()). */
  postCsrf: <T>(path: string, body: unknown, csrf: string) =>
    request<T>(path, {
      method: 'POST',
      headers: { 'X-CSRF-Token': csrf },
      body: JSON.stringify(body),
    }),
  /** POST multipart (upload de imagem) com CSRF no header. */
  postMultipart: <T>(path: string, form: FormData, csrf: string) =>
    request<T>(path, {
      method: 'POST',
      headers: { 'X-CSRF-Token': csrf },
      body: form,
    }),
  /** POST pra um endpoint fora de admin/ (ex: /api/create_charge.php na raiz do site). */
  postRoot: <T>(path: string, body?: unknown) =>
    request<T>(path, { method: 'POST', body: body ? JSON.stringify(body) : undefined }, ''),
}

export interface Me {
  id: number
  username: string
  site_name: string
  is_owner: boolean
  has_api_key: boolean
  nominal: string
  csrf: string
}
