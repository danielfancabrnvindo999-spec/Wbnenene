# admin-app — painel do Gateway Pix (React)

Código-fonte do painel de admin. Você só precisa mexer aqui se quiser
customizar o visual — pra só usar o sistema, ignore esta pasta e suba
`admin/app/` (já compilado) junto do resto do projeto.

## Rodando localmente

```bash
npm install
npm run dev
```

O `vite.config.ts` faz proxy de `/api` pro backend PHP rodando em
`http://localhost/gateway-base-seguidores/gateway-base-seguidores` —
ajuste esse endereço se seu ambiente local for diferente (XAMPP, MAMP,
`php -S`, etc.).

## Gerando o build de produção

```bash
npm run build
```

O build sai direto em `../admin/app` (fora desta pasta) — é esse
diretório que o servidor PHP serve em produção. Depois de buildar,
suba os arquivos novos de `admin/app/` pro seu servidor.

## Stack

React 19 + TypeScript + Tailwind CSS v4 + React Router + TanStack
Query + React Hook Form + Zod + Radix UI + Recharts + Sonner + Lucide.
