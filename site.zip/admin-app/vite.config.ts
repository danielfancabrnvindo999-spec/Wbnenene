import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import { defineConfig } from 'vite'
import path from 'path'

const dirname = import.meta.dirname

// SPA do painel admin. Build vai pra admin/app/ e é servido por trás do
// mesmo domínio PHP — todas as chamadas de API usam caminho relativo
// (../api/...) pra reaproveitar a sessão PHP (cookie httponly), sem CORS.
export default defineConfig({
  plugins: [react(), tailwindcss()],
  base: '/admin/app/',
  resolve: {
    alias: { '@': path.resolve(dirname, './src') },
  },
  build: {
    outDir: '../admin/app',
    emptyOutDir: true,
  },
  server: {
    proxy: {
      '/api': 'http://localhost/gateway-base-seguidores/gateway-base-seguidores',
    },
  },
})
