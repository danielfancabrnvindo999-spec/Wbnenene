<?php
require_once __DIR__ . '/includes/db.php';

$slug = $_GET['p'] ?? '';
$stmt = db()->prepare("SELECT * FROM products WHERE slug = ? AND active = 1");
$stmt->execute([$slug]);
$product = $stmt->fetch(PDO::FETCH_ASSOC);

$siteName = 'Meu Gateway Pix';
if ($product) {
    $ownerStmt = db()->prepare("SELECT site_name FROM users WHERE id = ?");
    $ownerStmt->execute([$product['user_id']]);
    $siteName = $ownerStmt->fetchColumn() ?: $siteName;
}
$brandInitial = strtoupper(substr($siteName, 0, 1) ?: 'P');

if (!$product) {
    http_response_code(404);
    ?>
    <!doctype html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo htmlspecialchars($siteName, ENT_QUOTES); ?></title>
        <link rel="stylesheet" href="assets/style.css?v=<?php echo time(); ?>">
    </head>
    <body>
        <div class="wrap">
            <div class="public-header">
                <div class="public-avatar"><?php echo htmlspecialchars($brandInitial, ENT_QUOTES); ?></div>
                <div class="brand"><?php echo htmlspecialchars($siteName, ENT_QUOTES); ?></div>
            </div>
            <div class="card error-box">Este link de pagamento não existe ou foi desativado.</div>
        </div>
    </body>
    </html>
    <?php
    exit;
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($product['name'], ENT_QUOTES); ?> — <?php echo htmlspecialchars($siteName, ENT_QUOTES); ?></title>
    <link rel="stylesheet" href="assets/style.css?v=<?php echo time(); ?>">
</head>
<body>
    <div class="wrap">
        <div class="public-header">
            <div class="public-avatar"><?php echo htmlspecialchars($brandInitial, ENT_QUOTES); ?></div>
            <div class="brand"><?php echo htmlspecialchars($siteName, ENT_QUOTES); ?></div>
            <span class="public-subtitle">Pagamento instantâneo via Pix</span>
        </div>

        <?php $semEstoque = $product['stock'] !== null && (int) $product['stock'] <= 0; ?>

        <div class="card" id="form-card">
            <?php if ($product['image_path']): ?>
                <img src="<?php echo htmlspecialchars($product['image_path'], ENT_QUOTES); ?>" alt="" class="product-cover">
            <?php endif; ?>
            <h3 style="margin-top:0;"><?php echo htmlspecialchars($product['name'], ENT_QUOTES); ?></h3>
            <?php if ($product['description']): ?>
                <p class="hint" style="font-size:0.85rem;"><?php echo htmlspecialchars($product['description'], ENT_QUOTES); ?></p>
            <?php endif; ?>
            <p style="font-size:1.6rem; font-weight:800; margin: 1rem 0;">R$ <?php echo number_format((float)$product['price'], 2, ',', '.'); ?></p>

            <?php if ($semEstoque): ?>
                <div class="error-box">Produto esgotado no momento.</div>
            <?php else: ?>
                <label for="customer_name">Seu nome (opcional)</label>
                <input type="text" id="customer_name" maxlength="120">

                <label for="coupon_code">Cupom de desconto (opcional)</label>
                <input type="text" id="coupon_code" maxlength="40" style="text-transform: uppercase;">

                <button id="btn-gerar">Pagar com Pix</button>
                <div id="erro" class="error-box" style="display:none;"></div>

                <div class="secure-note">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                    <span>Ambiente seguro · seus dados não são compartilhados</span>
                </div>
            <?php endif; ?>
        </div>

        <?php if (!$semEstoque): ?>
        <div class="card pix-box" id="pix-card" style="display:none;">
            <span class="status-tag status-pending" id="status-tag">Aguardando pagamento</span>
            <img id="qr-img" src="" alt="QR Code Pix">
            <p class="hint">Abra o app do seu banco, escaneie o QR Code acima ou copie o código abaixo na opção "Pix Copia e Cola".</p>
            <div class="pix-code" id="pix-code"></div>
            <button class="btn-outline" id="btn-copiar">Copiar código</button>
            <p class="pix-timer" id="pix-timer">Verificando pagamento automaticamente...</p>
            <a href="#" id="btn-continuar" class="btn" style="display:none; margin-top:0.75rem;">Continuar →</a>
        </div>
        <?php endif; ?>
    </div>

    <script>
        const slug       = <?php echo json_encode($product['slug']); ?>;
        const btnGerar   = document.getElementById('btn-gerar');
        const erroBox    = document.getElementById('erro');
        const formCard   = document.getElementById('form-card');
        const pixCard    = document.getElementById('pix-card');
        const qrImg      = document.getElementById('qr-img');
        const pixCodeBox = document.getElementById('pix-code');
        const statusTag  = document.getElementById('status-tag');
        const btnCopiar  = document.getElementById('btn-copiar');
        const pixTimer   = document.getElementById('pix-timer');
        const btnContinuar = document.getElementById('btn-continuar');

        let pollTimer = null;

        btnGerar.addEventListener('click', async () => {
            erroBox.style.display = 'none';
            btnGerar.disabled = true;
            btnGerar.innerHTML = '<span class="spinner"></span>Gerando...';

            try {
                const res = await fetch('api/create_charge.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        product_slug: slug,
                        customer_name: document.getElementById('customer_name').value,
                        coupon_code: document.getElementById('coupon_code').value,
                    }),
                });
                const data = await res.json();

                if (!res.ok) {
                    throw new Error(data.error || 'Erro ao gerar o Pix.');
                }

                qrImg.src = data.qr_image;
                pixCodeBox.textContent = data.pix_code;
                formCard.style.display = 'none';
                pixCard.style.display = 'block';

                pollTimer = setInterval(() => checarStatus(data.external_id), 5000);
            } catch (e) {
                erroBox.textContent = e.message;
                erroBox.style.display = 'block';
            } finally {
                btnGerar.disabled = false;
                btnGerar.textContent = 'Pagar com Pix';
            }
        });

        btnCopiar.addEventListener('click', () => {
            navigator.clipboard.writeText(pixCodeBox.textContent);
            btnCopiar.textContent = 'Copiado!';
            setTimeout(() => { btnCopiar.textContent = 'Copiar código'; }, 2000);
        });

        async function checarStatus(externalId) {
            try {
                const res = await fetch('api/check_status.php?external_id=' + encodeURIComponent(externalId));
                const data = await res.json();
                if (data.status === 'paid') {
                    statusTag.textContent = '✓ Pagamento confirmado!';
                    statusTag.className = 'status-tag status-paid';
                    pixTimer.textContent = 'Tudo certo! Pagamento recebido com sucesso.';
                    if (data.redirect_url) {
                        btnContinuar.href = data.redirect_url;
                        btnContinuar.style.display = 'block';
                    }
                    clearInterval(pollTimer);
                }
            } catch (e) { /* tenta de novo no próximo ciclo */ }
        }
    </script>
</body>
</html>
