<?php
/**
 * Notificação de venda no Telegram (opcional). Baseado no mesmo princípio
 * do TelegramService da LunarPay: dispara uma mensagem simples pro dono
 * quando uma venda é confirmada. Configurado em admin/settings.php.
 *
 * Multi-usuário: token/chat ficam na linha do próprio usuário (tabela
 * `users`), por isso a função recebe o `userId` — nunca uma configuração
 * global.
 *
 * Nunca deve travar o fluxo de pagamento — se o Telegram falhar, a venda
 * já foi marcada como paga de qualquer forma (por isso o try/catch aqui
 * fica isolado, chamado só DEPOIS do UPDATE em webhook.php).
 */
require_once __DIR__ . '/db.php';

function telegram_notify_sale(int $userId, string $productName, float $amount, string $customerName): void
{
    $stmt = db()->prepare("SELECT site_name, telegram_bot_token, telegram_chat_id FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $owner = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$owner) {
        return;
    }

    $token  = (string) $owner['telegram_bot_token'];
    $chatId = (string) $owner['telegram_chat_id'];

    if ($token === '' || $chatId === '') {
        return;
    }

    $siteName = $owner['site_name'];
    $cliente  = $customerName !== '' ? $customerName : 'Cliente anônimo';
    $valor    = number_format($amount, 2, ',', '.');

    $text = "💰 *Nova venda em {$siteName}!*\n"
          . "Produto: {$productName}\n"
          . "Cliente: {$cliente}\n"
          . "Valor: R$ {$valor}";

    try {
        $ch = curl_init("https://api.telegram.org/bot{$token}/sendMessage");
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
            'chat_id'    => $chatId,
            'text'       => $text,
            'parse_mode' => 'Markdown',
        ]));
        curl_exec($ch);
        curl_close($ch);
    } catch (\Throwable $e) {
        // Silencioso de propósito — notificação nunca pode derrubar o webhook.
    }
}
