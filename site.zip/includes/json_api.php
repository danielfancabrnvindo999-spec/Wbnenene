<?php
/**
 * Helper comum pros endpoints JSON novos em admin/api/ (usados pela SPA
 * React). Cada endpoint continua chamando require_login()/require_owner()
 * de includes/auth.php normalmente — isso aqui só padroniza saída/erro.
 */

function json_out($data, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function json_error(string $message, int $status = 400): void
{
    json_out(['error' => $message], $status);
}

function json_body(): array
{
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

/**
 * Versão JSON de require_login(): em vez de redirecionar pro login.php
 * (que faria a SPA receber um 200 com HTML em vez de JSON), responde
 * 401 direto — o fetch do React trata isso como "não autenticado".
 */
function require_login_json(): void
{
    if (empty($_SESSION['user_id'])) {
        json_error('unauthenticated', 401);
    }
    $sessionUser = current_user();
    if ($sessionUser === null || (int) ($sessionUser['active'] ?? 1) !== 1) {
        session_destroy();
        json_error('unauthenticated', 401);
    }
}

/** CSRF pra JSON: manda o token no header X-CSRF-Token em vez de campo de form. */
function check_csrf_header(): void
{
    $sent = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if ($sent === '' || empty($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $sent)) {
        json_error('Token de segurança inválido.', 403);
    }
}
