<?php
/**
 * Sessão + CSRF do painel de admin. Multi-usuário: a sessão guarda
 * `user_id` (não mais um "admin único"). Simples de propósito (este
 * projeto é um ponto de partida pra quem está aprendendo, não um
 * framework).
 */
require_once __DIR__ . '/db.php';

if (session_status() === PHP_SESSION_NONE) {
    // Cookie de sessão endurecido: HttpOnly (JS não lê), SameSite=Lax
    // (mitiga CSRF de origem cruzada) e Secure quando o site está em
    // HTTPS (nunca manda o cookie em texto puro por HTTP).
    $isHttps = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'secure'   => $isHttps,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

// Expiração por inatividade reduz o impacto de sessão roubada.
if (!empty($_SESSION['last_activity']) && time() - (int) $_SESSION['last_activity'] > 1800) {
    $_SESSION = [];
    session_destroy();
    session_start();
}
$_SESSION['last_activity'] = time();

/** Bloqueia a página pra quem não estiver logado. */
function require_login(): void
{
    if (empty($_SESSION['user_id'])) {
        header('Location: login.php');
        exit;
    }
    $sessionUser = current_user();
    if ($sessionUser === null || (int) ($sessionUser['active'] ?? 1) !== 1) {
        // Sessão órfã (usuário apagado, por exemplo) — desloga.
        session_destroy();
        header('Location: login.php');
        exit;
    }
}

/** Retorna a linha do usuário logado (ou null se não houver sessão).
 *  Passe true depois de atualizar o próprio usuário no banco (settings.php,
 *  change_admin.php) pra não pegar o valor cacheado da primeira leitura. */
function current_user(bool $forceRefresh = false): ?array
{
    static $user = null;
    static $loaded = false;
    if ($loaded && !$forceRefresh) return $user;
    $loaded = true;

    if (empty($_SESSION['user_id'])) {
        return null;
    }
    $stmt = db()->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $user = $row ?: null;
    return $user;
}

/** Atalho pro id do usuário logado. Só chame depois de require_login(). */
function current_user_id(): int
{
    return (int) ($_SESSION['user_id'] ?? 0);
}

/** Cada usuário normal possui seu próprio gateway isolado. */
function current_account_id(): int
{
    return current_user_id();
}

function current_user_is_owner(): bool
{
    return (current_user()['role'] ?? 'owner') === 'owner';
}

function require_owner(): void
{
    require_login();
    if (!current_user_is_owner()) {
        http_response_code(403);
        exit('Acesso exclusivo do proprietário.');
    }
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function check_csrf(): void
{
    $sent = $_POST['csrf'] ?? '';
    if ($sent === '' || empty($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $sent)) {
        http_response_code(403);
        exit('Token de segurança inválido. Volte e tente de novo.');
    }
}

function client_ip(): string
{
    return substr((string) ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'), 0, 45);
}

function application_origin(): string
{
    $host = strtolower((string) ($_SERVER['HTTP_HOST'] ?? ''));
    $serverName = strtolower((string) ($_SERVER['SERVER_NAME'] ?? ''));
    if (!preg_match('/^[a-z0-9.-]+(?::\d{1,5})?$/', $host)) {
        throw new RuntimeException('Host inválido.');
    }
    $hostName = explode(':', $host, 2)[0];
    if ($serverName !== '' && $serverName !== 'localhost' && $hostName !== $serverName) {
        throw new RuntimeException('Host não autorizado.');
    }
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || strtolower((string) ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https';
    return ($https ? 'https://' : 'http://') . $host;
}
