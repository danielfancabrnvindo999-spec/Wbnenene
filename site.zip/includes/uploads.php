<?php
/**
 * Upload de imagem de capa dos produtos (admin/produtos.php).
 *
 * Regras de segurança que importam aqui:
 * 1. Nunca confia na extensão do arquivo que o navegador mandou — o tipo
 *    real é decidido por getimagesize() (que abre os bytes e confere se é
 *    mesmo uma imagem) e pelo finfo (MIME real), não pelo nome do arquivo.
 * 2. O nome salvo é sempre gerado aleatoriamente — nunca usa o nome
 *    original (evita path traversal e sobrescrever arquivo de outro usuário).
 * 3. A pasta de destino tem um .htaccess que desliga a execução de PHP,
 *    então mesmo que alguém driblasse a validação, o arquivo salvo não
 *    rodaria como script.
 */

define('PRODUCT_UPLOAD_DIR', __DIR__ . '/../assets/uploads/products');
define('PRODUCT_UPLOAD_MAX_BYTES', 3 * 1024 * 1024); // 3 MB

const PRODUCT_IMAGE_ALLOWED_TYPES = [
    IMAGETYPE_JPEG => 'jpg',
    IMAGETYPE_PNG  => 'png',
    IMAGETYPE_WEBP => 'webp',
    IMAGETYPE_GIF  => 'gif',
];

/**
 * Processa $_FILES['campo']. Retorna o caminho relativo salvo (pra
 * gravar em products.image_path) ou lança Exception com mensagem
 * segura pra mostrar ao usuário.
 */
function handle_product_image_upload(array $file): string
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        throw new RuntimeException('__NO_FILE__'); // sentinela: nenhum arquivo enviado
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Falha no envio da imagem. Tente de novo.');
    }
    if (!is_uploaded_file($file['tmp_name'])) {
        throw new RuntimeException('Upload inválido.');
    }
    if ($file['size'] > PRODUCT_UPLOAD_MAX_BYTES) {
        throw new RuntimeException('Imagem muito grande — o limite é 3 MB.');
    }

    $info = @getimagesize($file['tmp_name']);
    if ($info === false || !isset(PRODUCT_IMAGE_ALLOWED_TYPES[$info[2]])) {
        throw new RuntimeException('Arquivo não é uma imagem válida (use JPG, PNG, WEBP ou GIF).');
    }

    if (!is_dir(PRODUCT_UPLOAD_DIR)) {
        mkdir(PRODUCT_UPLOAD_DIR, 0755, true);
    }

    $ext      = PRODUCT_IMAGE_ALLOWED_TYPES[$info[2]];
    $filename = bin2hex(random_bytes(16)) . '.' . $ext;
    $dest     = PRODUCT_UPLOAD_DIR . '/' . $filename;

    if (!move_uploaded_file($file['tmp_name'], $dest)) {
        throw new RuntimeException('Não foi possível salvar a imagem no servidor.');
    }

    return 'assets/uploads/products/' . $filename;
}

/** Apaga a imagem antiga do disco (ignora silenciosamente se não existir). */
function delete_product_image(?string $relativePath): void
{
    // Só apaga caminhos que a própria função de upload gera — defesa extra
    // caso esse valor um dia venha de outro lugar sem passar pela validação.
    if (!$relativePath || strpos($relativePath, 'assets/uploads/products/') !== 0) {
        return;
    }
    $full = __DIR__ . '/../' . $relativePath;
    if (is_file($full)) {
        @unlink($full);
    }
}
