<?php
/**
 * Página inicial pública (raiz do site sem `?u=usuario`) — é a vitrine
 * que o dono divulga (bio do Instagram, anúncio, WhatsApp). Usa o nome
 * público do DONO da plataforma (Configurações → Nome público), então
 * personalizar o nome no painel já muda esta página inteira.
 *
 * Incluída por index.php; nunca acessada direto (includes/ é bloqueada
 * por .htaccess).
 */

$ownerName = (string) (db()->query("SELECT site_name FROM users WHERE role = 'owner' ORDER BY id LIMIT 1")->fetchColumn() ?: 'Gateway Pix');
$lpInitial = function_exists('mb_substr') ? mb_strtoupper(mb_substr($ownerName, 0, 1)) : strtoupper(substr($ownerName, 0, 1));
$lpName    = htmlspecialchars($ownerName, ENT_QUOTES);
$lpDesc    = 'Receba por Pix e boleto com link de pagamento próprio, cupons de desconto e painel completo de vendas. Crie sua conta grátis na ' . $ownerName . '.';
$lpDescEsc = htmlspecialchars($lpDesc, ENT_QUOTES);

// Só monta a URL canônica se o Host bater com o domínio configurado no
// servidor — nunca ecoa um Host arbitrário mandado pelo navegador.
$lpUrl  = '';
$lpHost = strtolower((string) ($_SERVER['HTTP_HOST'] ?? ''));
$lpSrv  = strtolower((string) ($_SERVER['SERVER_NAME'] ?? ''));
if ($lpSrv !== '' && preg_match('/^[a-z0-9.-]+$/', $lpHost) && $lpHost === $lpSrv) {
    $lpUrl = 'https://' . $lpHost . '/';
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $lpName; ?> — Gateway de pagamentos Pix</title>
    <meta name="description" content="<?php echo $lpDescEsc; ?>">
    <meta name="theme-color" content="#090a10">
    <meta property="og:type" content="website">
    <meta property="og:title" content="<?php echo $lpName; ?> — Receba por Pix na hora">
    <meta property="og:description" content="<?php echo $lpDescEsc; ?>">
    <?php if ($lpUrl !== ''): ?>
    <meta property="og:url" content="<?php echo htmlspecialchars($lpUrl, ENT_QUOTES); ?>">
    <link rel="canonical" href="<?php echo htmlspecialchars($lpUrl, ENT_QUOTES); ?>">
    <?php endif; ?>
    <meta name="twitter:card" content="summary">
    <link rel="icon" href="favicon.svg" type="image/svg+xml">
    <link rel="stylesheet" href="assets/style.css?v=<?php echo @filemtime(__DIR__ . '/../assets/style.css') ?: 1; ?>">
</head>
<body class="lp">
    <header class="lp-nav">
        <div class="lp-container lp-nav-inner">
            <a href="./" class="lp-logo">
                <span class="public-avatar lp-logo-mark"><?php echo htmlspecialchars($lpInitial, ENT_QUOTES); ?></span>
                <span><?php echo $lpName; ?></span>
            </a>
            <nav class="lp-nav-links">
                <a href="#recursos">Recursos</a>
                <a href="#como-funciona">Como funciona</a>
                <a href="#duvidas">Dúvidas</a>
                <a href="admin/login.php" class="lp-nav-login">Entrar</a>
            </nav>
        </div>
    </header>

    <main>
        <section class="lp-hero">
            <div class="lp-container">
                <span class="lp-eyebrow">Pix · Boleto</span>
                <h1>Receba seus pagamentos por Pix <span>na hora</span>, com link próprio.</h1>
                <p class="lp-lead">Crie sua conta, cadastre seu produto e mande o link pro seu cliente. O dinheiro cai na hora e você acompanha tudo num painel simples.</p>
                <div class="lp-cta-row">
                    <a href="admin/registro.php" class="btn lp-btn">Criar minha conta grátis</a>
                    <a href="admin/login.php" class="btn btn-outline lp-btn">Já tenho conta</a>
                </div>
                <ul class="lp-trust">
                    <li>Sem mensalidade pra começar</li>
                    <li>Confirmação automática</li>
                    <li>Painel no celular</li>
                </ul>
            </div>
        </section>

        <section id="recursos" class="lp-section">
            <div class="lp-container">
                <h2>Tudo que você precisa pra vender</h2>
                <div class="lp-grid">
                    <div class="card lp-feature">
                        <h3>Pix instantâneo</h3>
                        <p>QR Code e copia-e-cola gerados na hora. O pagamento é confirmado sozinho, sem você conferir extrato.</p>
                    </div>
                    <div class="card lp-feature">
                        <h3>Link de pagamento</h3>
                        <p>Cadastre o produto uma vez e ganhe um link fixo pra bio do Instagram, WhatsApp ou anúncio.</p>
                    </div>
                    <div class="card lp-feature">
                        <h3>Boleto bancário</h3>
                        <p>Aceite boleto com linha digitável, compensação em 1 a 3 dias úteis, quando sua conta LunarPay tiver esse método habilitado.</p>
                    </div>
                    <div class="card lp-feature">
                        <h3>Cupons de desconto</h3>
                        <p>Crie códigos promocionais pra campanhas e lançamentos. O desconto é validado no servidor.</p>
                    </div>
                    <div class="card lp-feature">
                        <h3>Aviso no Telegram</h3>
                        <p>Receba uma notificação no celular a cada venda confirmada, na hora em que acontece.</p>
                    </div>
                    <div class="card lp-feature">
                        <h3>Painel de vendas</h3>
                        <p>Gráfico, extrato com filtro, exportação pra planilha, estoque e reembolso num lugar só.</p>
                    </div>
                </div>
            </div>
        </section>

        <section id="como-funciona" class="lp-section">
            <div class="lp-container">
                <h2>Comece a vender em 3 passos</h2>
                <ol class="lp-steps">
                    <li class="card"><span class="lp-step-num">1</span><div><h3>Crie sua conta</h3><p>Leva menos de um minuto: usuário, nome da sua loja e senha.</p></div></li>
                    <li class="card"><span class="lp-step-num">2</span><div><h3>Cadastre seu produto</h3><p>Nome, valor e, se quiser, imagem, estoque e link de entrega.</p></div></li>
                    <li class="card"><span class="lp-step-num">3</span><div><h3>Compartilhe o link</h3><p>Mande pro cliente. Ele paga pelo Pix e você recebe o aviso na hora.</p></div></li>
                </ol>
            </div>
        </section>

        <section id="duvidas" class="lp-section">
            <div class="lp-container lp-narrow">
                <h2>Dúvidas frequentes</h2>
                <details class="card lp-faq">
                    <summary>Preciso de CNPJ?</summary>
                    <p>As regras de cadastro e recebimento seguem a processadora de pagamentos. Crie sua conta e siga o passo a passo do painel.</p>
                </details>
                <details class="card lp-faq">
                    <summary>Em quanto tempo o dinheiro cai?</summary>
                    <p>No Pix, a confirmação é na hora. Boleto compensa em 1 a 3 dias úteis após o pagamento.</p>
                </details>
                <details class="card lp-faq">
                    <summary>Meus dados e os do meu cliente ficam seguros?</summary>
                    <p>Sim. O site roda em HTTPS, cada conta é isolada e o login tem proteção contra tentativa de senha.</p>
                </details>
                <details class="card lp-faq">
                    <summary>Consigo usar pelo celular?</summary>
                    <p>Sim. O painel e o checkout funcionam em qualquer celular, sem instalar aplicativo.</p>
                </details>
            </div>
        </section>

        <section class="lp-section">
            <div class="lp-container lp-narrow">
                <div class="card lp-final">
                    <h2>Pronto pra receber sua primeira venda?</h2>
                    <p>Crie sua conta grátis na <?php echo $lpName; ?> e gere seu primeiro link de pagamento hoje.</p>
                    <a href="admin/registro.php" class="btn lp-btn">Criar minha conta grátis</a>
                </div>
            </div>
        </section>
    </main>

    <footer class="lp-footer">
        <div class="lp-container">
            <span>© <?php echo date('Y'); ?> <?php echo $lpName; ?></span>
            <span>Pagamentos processados pela LunarPay</span>
        </div>
    </footer>
</body>
</html>
