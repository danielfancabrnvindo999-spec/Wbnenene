<?php
/**
 * Banco local (SQLite, um arquivo só, sem precisar configurar MySQL).
 *
 * Multi-usuário: cada linha de `users` é um gateway independente (login
 * próprio, chave da LunarPay própria, produtos/vendas/cupons isolados por
 * `user_id`). `pagar.php?p=slug` funciona sem precisar saber de quem é o
 * link porque o slug já carrega o dono (`products.user_id`); o checkout de
 * valor livre (`index.php?u=usuario`) precisa do usuário na URL porque não
 * existe produto pra apontar o dono.
 *
 * O arquivo fica em data/gateway.sqlite, protegido por .htaccess (ver
 * data/.htaccess) — nunca deve ser acessível direto pelo navegador.
 */

define('DB_PATH', __DIR__ . '/../data/gateway.sqlite');

// Headers de segurança básicos em TODA requisição — db.php é o primeiro
// require de qualquer página do projeto (público ou admin), então isso
// cobre o site inteiro de um lugar só.
if (!headers_sent()) {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: geolocation=(), microphone=(), camera=()');
}

function db(): PDO
{
    static $pdo = null;
    if ($pdo !== null) return $pdo;

    $isNew = !file_exists(DB_PATH);
    if (!is_dir(dirname(DB_PATH))) {
        mkdir(dirname(DB_PATH), 0755, true);
    }

    $pdo = new PDO('sqlite:' . DB_PATH);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Tabela legada (chave/valor) — mantida só pra migração de instalações
    // antigas (ver bloco de migração abaixo). Instalações novas não usam.
    $pdo->exec("CREATE TABLE IF NOT EXISTS settings (
        `key` TEXT PRIMARY KEY,
        `value` TEXT
    )");

    // Uma instalação = um gateway e um único administrador.
    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        site_name TEXT NOT NULL DEFAULT 'Meu Gateway Pix',
        lunarpay_api_key TEXT NOT NULL DEFAULT '',
        telegram_bot_token TEXT NOT NULL DEFAULT '',
        telegram_chat_id TEXT NOT NULL DEFAULT '',
        role TEXT NOT NULL DEFAULT 'owner',
        owner_id INTEGER,
        active INTEGER NOT NULL DEFAULT 1,
        nominal TEXT NOT NULL DEFAULT 'nominal1',
        api_token TEXT,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        external_id TEXT UNIQUE NOT NULL,
        pix_id TEXT,
        amount REAL NOT NULL,
        product_id INTEGER,
        product_name TEXT,
        customer_name TEXT,
        coupon_code TEXT,
        status TEXT NOT NULL DEFAULT 'pending',
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        paid_at TEXT
        ,refunded_at TEXT
        ,payment_method TEXT NOT NULL DEFAULT 'pix'
        ,payment_url TEXT
        ,payment_code TEXT
    )");

    // Produtos com link de pagamento fixo — o "gerador de link" do painel
    // (admin/produtos.php): cadastra uma vez, gera uma URL pra compartilhar
    // (ex: WhatsApp, bio do Instagram) que sempre cobra o mesmo valor. O
    // slug é único no banco inteiro (não só por usuário) porque a URL
    // pública (pagar.php?p=slug) não carrega o nome de usuário.
    $pdo->exec("CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        slug TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        description TEXT,
        price REAL NOT NULL,
        image_path TEXT,
        stock INTEGER,
        redirect_url TEXT,
        active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )");

    // Cupons de desconto — código único POR usuário (dois donos diferentes
    // podem usar o mesmo código sem conflito). O desconto é sempre
    // recalculado no servidor em api/create_charge.php.
    $pdo->exec("CREATE TABLE IF NOT EXISTS coupons (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        code TEXT NOT NULL,
        percent_off REAL NOT NULL,
        active INTEGER NOT NULL DEFAULT 1,
        uses INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        UNIQUE(user_id, code)
    )");

    // Anti-força-bruta do login: guarda tentativas falhas por usuário+IP.
    // Consultado em admin/login.php antes de sequer checar a senha.
    $pdo->exec("CREATE TABLE IF NOT EXISTS login_attempts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL,
        ip TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS request_limits (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        action TEXT NOT NULL,
        identity TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_request_limits ON request_limits(action, identity, created_at)");

    $pdo->exec("CREATE TABLE IF NOT EXISTS audit_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        event TEXT NOT NULL,
        target_id INTEGER,
        ip TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )");

    // Pedido de saque do membro. Fica "pending" até o dono aprovar — só aí
    // a chamada real pra LunarPay acontece (ver admin/api/saques_admin.php).
    // O saque nunca é automático: sempre passa pela revisão do dono.
    $pdo->exec("CREATE TABLE IF NOT EXISTS withdrawal_requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        amount REAL NOT NULL,
        pix_key TEXT NOT NULL,
        pix_key_type TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending',
        reject_reason TEXT,
        lunarpay_withdrawal_id TEXT,
        lunarpay_response TEXT,
        reviewed_by INTEGER,
        reviewed_at TEXT,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_withdrawal_requests_user ON withdrawal_requests(user_id, created_at)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_withdrawal_requests_status ON withdrawal_requests(status, created_at)");

    if (!$isNew) {
        // Migração de instalações antigas (single-tenant, antes da tabela
        // `users` existir): se `users` está vazia mas a `settings` legada
        // tem um admin cadastrado, converte esse admin único no primeiro
        // usuário e transfere pedidos/produtos/cupons pra ele. Roda uma
        // única vez — depois disso `users` nunca mais fica vazia.
        $hasUsers = (int) $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
        if ($hasUsers === 0) {
            $legacyUser = $pdo->query("SELECT `value` FROM settings WHERE `key` = 'admin_user'")->fetchColumn();
            if ($legacyUser !== false) {
                $get = function (string $key, string $default = '') use ($pdo): string {
                    $v = $pdo->query("SELECT `value` FROM settings WHERE `key` = " . $pdo->quote($key))->fetchColumn();
                    return $v === false ? $default : (string) $v;
                };
                $legacyHash     = $get('admin_pass_hash');
                $legacySiteName = $get('site_name', 'Meu Gateway Pix');
                $legacyApiKey   = $get('lunarpay_api_key');
                $legacyTgToken  = $get('telegram_bot_token');
                $legacyTgChat   = $get('telegram_chat_id');

                $pdo->prepare(
                    "INSERT INTO users (username, password_hash, site_name, lunarpay_api_key, telegram_bot_token, telegram_chat_id)
                     VALUES (?, ?, ?, ?, ?, ?)"
                )->execute([$legacyUser, $legacyHash, $legacySiteName, $legacyApiKey, $legacyTgToken, $legacyTgChat]);

                $newUserId = (int) $pdo->lastInsertId();
                $pdo->prepare("UPDATE orders SET user_id = ? WHERE user_id IS NULL")->execute([$newUserId]);
                $pdo->prepare("UPDATE products SET user_id = ? WHERE user_id IS NULL")->execute([$newUserId]);
                // Cupons antigos não tinham dono nem UNIQUE por usuário — se
                // a tabela antiga existir com layout diferente, o CREATE TABLE
                // IF NOT EXISTS acima não a recria; o ALTER abaixo cobre isso.
            }
        }

        // Migração leve de colunas que podem faltar em instalações mais
        // antigas, sem apagar nada do banco existente.
        $orderCols = array_column($pdo->query("PRAGMA table_info(orders)")->fetchAll(PDO::FETCH_ASSOC), 'name');
        if (!in_array('product_id', $orderCols, true)) {
            $pdo->exec("ALTER TABLE orders ADD COLUMN product_id INTEGER");
        }
        if (!in_array('coupon_code', $orderCols, true)) {
            $pdo->exec("ALTER TABLE orders ADD COLUMN coupon_code TEXT");
        }
        if (!in_array('user_id', $orderCols, true)) {
            $pdo->exec("ALTER TABLE orders ADD COLUMN user_id INTEGER");
        }

        $productCols = array_column($pdo->query("PRAGMA table_info(products)")->fetchAll(PDO::FETCH_ASSOC), 'name');
        if (!in_array('user_id', $productCols, true)) {
            $pdo->exec("ALTER TABLE products ADD COLUMN user_id INTEGER");
        }
        if (!in_array('image_path', $productCols, true)) {
            $pdo->exec("ALTER TABLE products ADD COLUMN image_path TEXT");
        }
        if (!in_array('stock', $productCols, true)) {
            $pdo->exec("ALTER TABLE products ADD COLUMN stock INTEGER");
        }
        if (!in_array('redirect_url', $productCols, true)) {
            $pdo->exec("ALTER TABLE products ADD COLUMN redirect_url TEXT");
        }

        $couponCols = array_column($pdo->query("PRAGMA table_info(coupons)")->fetchAll(PDO::FETCH_ASSOC), 'name');
        if (!in_array('user_id', $couponCols, true)) {
            $pdo->exec("ALTER TABLE coupons ADD COLUMN user_id INTEGER");
        }

        $userCols = array_column($pdo->query("PRAGMA table_info(users)")->fetchAll(PDO::FETCH_ASSOC), 'name');
        if (!in_array('role', $userCols, true)) {
            $pdo->exec("ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'owner'");
        }
        if (!in_array('owner_id', $userCols, true)) {
            $pdo->exec("ALTER TABLE users ADD COLUMN owner_id INTEGER");
        }
        if (!in_array('active', $userCols, true)) {
            $pdo->exec("ALTER TABLE users ADD COLUMN active INTEGER NOT NULL DEFAULT 1");
        }
        if (!in_array('nominal', $userCols, true)) {
            $pdo->exec("ALTER TABLE users ADD COLUMN nominal TEXT NOT NULL DEFAULT 'nominal1'");
        }
        if (!in_array('api_token', $userCols, true)) {
            $pdo->exec("ALTER TABLE users ADD COLUMN api_token TEXT");
        }
        if (!in_array('refunded_at', $orderCols, true)) {
            $pdo->exec("ALTER TABLE orders ADD COLUMN refunded_at TEXT");
        }
        if (!in_array('payment_method', $orderCols, true)) {
            $pdo->exec("ALTER TABLE orders ADD COLUMN payment_method TEXT NOT NULL DEFAULT 'pix'");
        }
        if (!in_array('payment_url', $orderCols, true)) {
            $pdo->exec("ALTER TABLE orders ADD COLUMN payment_url TEXT");
        }
        if (!in_array('payment_code', $orderCols, true)) {
            $pdo->exec("ALTER TABLE orders ADD COLUMN payment_code TEXT");
        }
        // Bancos vindos da versão sem papéis podem ter várias contas marcadas
        // pelo DEFAULT como owner. Só a primeira é dona da plataforma.
        $pdo->exec("UPDATE users SET role = 'user' WHERE id != (SELECT MIN(id) FROM users) AND role = 'owner'");
    }

    $pdo->exec("DROP TRIGGER IF EXISTS users_single_owner");
    // Um proprietário da plataforma; cadastros públicos entram como user.
    $pdo->exec("CREATE TRIGGER users_single_owner
        BEFORE INSERT ON users
        WHEN NEW.role = 'owner' AND (SELECT COUNT(*) FROM users WHERE role = 'owner') >= 1
        BEGIN
            SELECT RAISE(ABORT, 'single_owner_only');
        END");

    return $pdo;
}

function setting(string $key, $default = null)
{
    $stmt = db()->prepare("SELECT `value` FROM settings WHERE `key` = ?");
    $stmt->execute([$key]);
    $v = $stmt->fetchColumn();
    return $v === false ? $default : $v;
}

function set_setting(string $key, string $value): void
{
    $stmt = db()->prepare(
        "INSERT INTO settings (`key`, `value`) VALUES (?, ?)
         ON CONFLICT(`key`) DO UPDATE SET `value` = excluded.value"
    );
    $stmt->execute([$key, $value]);
}

function rate_limit_hit(string $action, string $identity, int $limit, int $minutes): bool
{
    $pdo = db();
    $pdo->prepare("DELETE FROM request_limits WHERE created_at < datetime('now', '-1 day')")->execute();
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM request_limits WHERE action = ? AND identity = ? AND created_at >= datetime('now', ?)");
    $stmt->execute([$action, $identity, '-' . $minutes . ' minutes']);
    if ((int) $stmt->fetchColumn() >= $limit) return true;
    $pdo->prepare('INSERT INTO request_limits (action, identity) VALUES (?, ?)')->execute([$action, $identity]);
    return false;
}

function audit_event(?int $userId, string $event, ?int $targetId = null, string $ip = ''): void
{
    db()->prepare('INSERT INTO audit_logs (user_id, event, target_id, ip) VALUES (?, ?, ?, ?)')
        ->execute([$userId, substr($event, 0, 80), $targetId, substr($ip, 0, 45)]);
}

/**
 * Anti-força-bruta simples do login: no máximo 5 tentativas falhas em 10
 * minutos pro mesmo usuário+IP. Não é um WAF de verdade, mas segura o
 * ataque mais óbvio (script tentando senha atrás de senha).
 */
function login_is_blocked(string $username, string $ip): bool
{
    $stmt = db()->prepare(
        "SELECT COUNT(*) FROM login_attempts
         WHERE username = ? AND ip = ? AND created_at >= datetime('now', '-10 minutes')"
    );
    $stmt->execute([$username, $ip]);
    return (int) $stmt->fetchColumn() >= 5;
}

function login_register_failure(string $username, string $ip): void
{
    db()->prepare("INSERT INTO login_attempts (username, ip) VALUES (?, ?)")->execute([$username, $ip]);
    // Limpeza oportunista pra tabela não crescer pra sempre.
    db()->exec("DELETE FROM login_attempts WHERE created_at < datetime('now', '-1 day')");
}

function login_clear_failures(string $username, string $ip): void
{
    db()->prepare("DELETE FROM login_attempts WHERE username = ? AND ip = ?")->execute([$username, $ip]);
}
