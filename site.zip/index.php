<?php
require_once __DIR__ . '/includes/db.php';

$username = trim($_GET['u'] ?? '');
$merchant = false;

if ($username !== '') {
    $stmt = db()->prepare("SELECT * FROM users WHERE username = ? AND active = 1");
    $stmt->execute([$username]);
    $merchant = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Sem `?u=usuario` (ou usuário inexistente) — mostra a landing do motor,
// não um checkout quebrado. É o caso de alguém abrir a raiz do site sem
// saber de quem é o gateway.
if ($merchant === false) {
    // Instalação nova (ninguém rodou setup.php ainda): manda direto pra
    // criação da conta de dono em vez de mostrar uma vitrine sem dono.
    if ((int) db()->query("SELECT COUNT(*) FROM users")->fetchColumn() === 0) {
        header('Location: admin/setup.php');
        exit;
    }
    require __DIR__ . '/includes/landing.php';
    exit;
}

$siteName     = $merchant['site_name'];
$brandInitial = strtoupper(substr($siteName, 0, 1) ?: 'P');
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($siteName, ENT_QUOTES); ?></title>
    <link rel="stylesheet" href="assets/style.css?v=<?php echo time(); ?>">
</head>
<body>
    <div class="wrap">
        <div class="public-header">
            <div class="public-avatar"><?php echo htmlspecialchars($brandInitial, ENT_QUOTES); ?></div>
            <div class="brand"><?php echo htmlspecialchars($siteName, ENT_QUOTES); ?></div>
            <span class="public-subtitle">Pagamento instantâneo via Pix</span>
        </div>

        <div class="card" id="form-card">
            <span class="step-badge">Passo 1 de 2 · Dados da cobrança</span>

            <label for="amount">Valor (R$)</label>
            <input type="number" id="amount" min="5" step="0.01" value="29.90">

            <button id="btn-gerar">Gerar Pix</button>
            <div id="erro" class="error-box" style="display:none;"></div>

            <div class="secure-note">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                <span>Ambiente seguro · seus dados não são compartilhados</span>
            </div>
        </div>

        <div class="card pix-box" id="pix-card" style="display:none;">
            <span class="step-badge">Passo 2 de 2 · Pagar com Pix</span>
            <span class="status-tag status-pending" id="status-tag">Aguardando pagamento</span>
            <img id="qr-img" src="" alt="QR Code Pix">
            <p class="hint">Abra o app do seu banco, escaneie o QR Code acima ou copie o código abaixo na opção "Pix Copia e Cola".</p>
            <div class="pix-code" id="pix-code"></div>
            <button class="btn-outline" id="btn-copiar">Copiar código</button>
            <p class="pix-timer" id="pix-timer">Verificando pagamento automaticamente...</p>
        </div>
    </div>

    <script>
        const merchant   = <?php echo json_encode($username); ?>;
        const btnGerar   = document.getElementById('btn-gerar');
        const erroBox    = document.getElementById('erro');
        const formCard   = document.getElementById('form-card');
        const pixCard    = document.getElementById('pix-card');
        const qrImg      = document.getElementById('qr-img');
        const pixCodeBox = document.getElementById('pix-code');
        const statusTag  = document.getElementById('status-tag');
        const btnCopiar  = document.getElementById('btn-copiar');
        const pixTimer   = document.getElementById('pix-timer');

        let pollTimer = null;

        btnGerar.addEventListener('click', async () => {
            erroBox.style.display = 'none';
            btnGerar.disabled = true;
            btnGerar.innerHTML = '<span class="spinner"></span>Gerando...';

            try {
                const res = await fetch('api/create_charge.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        merchant: merchant,
                        amount: parseFloat(document.getElementById('amount').value || '0'),
                        product_name: 'Pagamento',
                        customer_name: '',
                        coupon_code: '',
                    }),
                });
                const data = await res.json();

                if (!res.ok) {
                    throw new Error(data.error || 'Erro ao gerar o Pix.');
                }

                qrImg.src = data.qr_image;
                pixCodeBox.textContent = data.pix_code;
                formCard.style.display = 'none';
                pixCard.style.display = 'block';

                pollTimer = setInterval(() => checarStatus(data.external_id), 5000);
            } catch (e) {
                erroBox.textContent = e.message;
                erroBox.style.display = 'block';
            } finally {
                btnGerar.disabled = false;
                btnGerar.textContent = 'Gerar Pix';
            }
        });

        btnCopiar.addEventListener('click', () => {
            navigator.clipboard.writeText(pixCodeBox.textContent);
            btnCopiar.textContent = 'Copiado!';
            setTimeout(() => { btnCopiar.textContent = 'Copiar código'; }, 2000);
        });

        async function checarStatus(externalId) {
            try {
                const res = await fetch('api/check_status.php?external_id=' + encodeURIComponent(externalId));
                const data = await res.json();
                if (data.status === 'paid') {
                    statusTag.textContent = '✓ Pagamento confirmado!';
                    statusTag.className = 'status-tag status-paid';
                    pixTimer.textContent = 'Tudo certo! Pagamento recebido com sucesso.';
                    clearInterval(pollTimer);
                }
            } catch (e) { /* tenta de novo no próximo ciclo */ }
        }
    </script>
</body>
</html>
