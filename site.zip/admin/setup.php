<?php
require_once __DIR__ . '/../includes/auth.php';

if ((int) db()->query("SELECT COUNT(*) FROM users WHERE role = 'owner'")->fetchColumn() > 0) {
    header('Location: login.php');
    exit;
}

$error = '';
$username = '';
$siteName = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $username = strtolower(trim($_POST['username'] ?? ''));
    $siteName = trim($_POST['site_name'] ?? '');
    $pass = (string) ($_POST['pass'] ?? '');
    $pass2 = (string) ($_POST['pass2'] ?? '');

    if (!preg_match('/^[a-z0-9_.-]{3,30}$/', $username)) {
        $error = 'Usuário inválido.';
    } elseif ($siteName === '') {
        $error = 'Informe o nome da plataforma.';
    } elseif (strlen($pass) < 12) {
        $error = 'A senha precisa ter pelo menos 12 caracteres.';
    } elseif ($pass !== $pass2) {
        $error = 'As senhas não são iguais.';
    } else {
        try {
            db()->prepare("INSERT INTO users (username, password_hash, site_name, role) VALUES (?, ?, ?, 'owner')")
                ->execute([$username, password_hash($pass, PASSWORD_DEFAULT), $siteName]);
            session_regenerate_id(true);
            $_SESSION['user_id'] = (int) db()->lastInsertId();
            header('Location: index.php');
            exit;
        } catch (PDOException $e) {
            $error = 'O proprietário da plataforma já foi configurado.';
        }
    }
}
$csrf = csrf_token();
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configuração inicial — Gateway Pix</title>
    <link rel="stylesheet" href="../assets/style.css?v=<?php echo time(); ?>">
</head>
<body>
    <main class="wrap">
        <div class="public-header">
            <div class="public-avatar" aria-hidden="true">G</div>
            <div class="brand">Configuração inicial</div>
            <span class="public-subtitle">Crie o proprietário da plataforma</span>
        </div>
        <div class="card">
            <?php if ($error): ?><div class="error-box" role="alert"><?php echo htmlspecialchars($error, ENT_QUOTES); ?></div><?php endif; ?>
            <form method="post">
                <input type="hidden" name="csrf" value="<?php echo htmlspecialchars($csrf, ENT_QUOTES); ?>">
                <label for="username">Usuário do proprietário</label>
                <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($username, ENT_QUOTES); ?>" maxlength="30" required autofocus>
                <label for="site_name">Nome da plataforma</label>
                <input type="text" id="site_name" name="site_name" value="<?php echo htmlspecialchars($siteName, ENT_QUOTES); ?>" maxlength="80" required>
                <label for="pass">Senha (mínimo 12 caracteres)</label>
                <input type="password" id="pass" name="pass" minlength="12" required autocomplete="new-password">
                <label for="pass2">Confirme a senha</label>
                <input type="password" id="pass2" name="pass2" minlength="12" required autocomplete="new-password">
                <button type="submit">Criar proprietário</button>
            </form>
            <div class="secure-note"><span>Esta etapa aparece somente na primeira instalação</span></div>
        </div>
    </main>
</body>
</html>
