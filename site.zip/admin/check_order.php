<?php
/**
 * Fallback de reconciliação (mesmo princípio do reconcile_safe.php da
 * LunarPay): se o webhook nunca chegou por algum motivo, o admin consulta
 * o status direto na API da LunarPay e atualiza o pedido manualmente.
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/lunarpay.php';
require_once __DIR__ . '/../includes/telegram.php';
require_login();

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Método não permitido.']);
    exit;
}
check_csrf();

$uid = current_user_id();
$id  = (int) ($_POST['id'] ?? 0);

// O "AND user_id = ?" impede um usuário consultar/alterar o pedido de
// outro adivinhando o id.
$stmt = db()->prepare("SELECT * FROM orders WHERE id = ? AND user_id = ?");
$stmt->execute([$id, $uid]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    http_response_code(404);
    echo json_encode(['error' => 'Pedido não encontrado.']);
    exit;
}

if ($order['status'] === 'paid') {
    echo json_encode(['status' => 'paid', 'already' => true]);
    exit;
}

$user = current_user();
$res = lunarpay_check_status($user['lunarpay_api_key'], $order['external_id']);
$remoteStatus = $res['data']['status'] ?? null;

if ($remoteStatus === 'paid') {
    $upd = db()->prepare("UPDATE orders SET status = 'paid', paid_at = datetime('now') WHERE id = ? AND status = 'pending'");
    $upd->execute([$id]);
    if ($upd->rowCount() > 0) {
        telegram_notify_sale($uid, (string) ($order['product_name'] ?: 'Produto Digital'), (float) $order['amount'], (string) ($order['customer_name'] ?? ''));
    }
    echo json_encode(['status' => 'paid']);
    exit;
}

echo json_encode(['status' => $remoteStatus ?? 'pending']);
