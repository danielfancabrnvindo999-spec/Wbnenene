<?php
// Painel novo é a SPA React em admin/app/ — fallback de compatibilidade
// pra quem tinha este link antigo salvo.
header('Location: app/cupons');
exit;
