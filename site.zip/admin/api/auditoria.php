<?php
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/json_api.php';

if (empty($_SESSION['user_id'])) json_error('unauthenticated', 401);
if (!current_user_is_owner()) json_error('forbidden', 403);

$event = trim((string) ($_GET['event'] ?? ''));
$sql = "SELECT a.*, u.username actor, t.username target FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id LEFT JOIN users t ON t.id=a.target_id";
$params = [];
if ($event !== '') { $sql .= ' WHERE a.event = ?'; $params[] = $event; }
$sql .= ' ORDER BY a.id DESC LIMIT 300';
$stmt = db()->prepare($sql);
$stmt->execute($params);
$logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
$events = db()->query('SELECT event, COUNT(*) total FROM audit_logs GROUP BY event ORDER BY total DESC')->fetchAll(PDO::FETCH_ASSOC);

json_out([
    'events' => array_map(static fn($e) => ['event' => $e['event'], 'total' => (int) $e['total']], $events),
    'logs'   => array_map(static fn($l) => [
        'id'         => (int) $l['id'],
        'event'      => $l['event'],
        'actor'      => $l['actor'],
        'target'     => $l['target'] ?? ($l['target_id'] ?: null),
        'ip'         => $l['ip'],
        'created_at' => $l['created_at'],
    ], $logs),
]);
