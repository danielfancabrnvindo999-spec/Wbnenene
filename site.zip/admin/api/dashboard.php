<?php
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/json_api.php';
require_login_json();

$user = current_user();
$uid  = current_user_id();

$totalsStmt = db()->prepare("
    SELECT
        SUM(CASE WHEN status = 'paid' THEN amount ELSE 0 END) AS total_pago,
        SUM(CASE WHEN status = 'paid' AND date(paid_at) = date('now') THEN amount ELSE 0 END) AS hoje,
        SUM(CASE WHEN status = 'paid' AND date(paid_at) = date('now') THEN 1 ELSE 0 END) AS vendas_hoje_count,
        SUM(CASE WHEN status = 'paid' AND strftime('%Y-%m', paid_at) = strftime('%Y-%m', 'now') THEN amount ELSE 0 END) AS volume_mes,
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pendentes,
        SUM(CASE WHEN status = 'paid' THEN 1 ELSE 0 END) AS pagos,
        COUNT(*) AS total_pedidos
    FROM orders WHERE user_id = ?
");
$totalsStmt->execute([$uid]);
$totals = $totalsStmt->fetch(PDO::FETCH_ASSOC);

$totalPago    = (float) ($totals['total_pago'] ?? 0);
$hojeValor    = (float) ($totals['hoje'] ?? 0);
$hojeVendas   = (int) ($totals['vendas_hoje_count'] ?? 0);
$volumeMes    = (float) ($totals['volume_mes'] ?? 0);
$pendentes    = (int) ($totals['pendentes'] ?? 0);
$totalPedidos = (int) ($totals['total_pedidos'] ?? 0);
$totalPagos   = (int) ($totals['pagos'] ?? 0);

$ordersStmt = db()->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC LIMIT 10");
$ordersStmt->execute([$uid]);
$orders = $ordersStmt->fetchAll(PDO::FETCH_ASSOC);

$prodCountStmt = db()->prepare("SELECT COUNT(*) FROM products WHERE user_id = ?");
$prodCountStmt->execute([$uid]);
$totalProdutos = (int) $prodCountStmt->fetchColumn();

$checklist = [
    ['done' => $user['lunarpay_api_key'] !== '', 'title' => 'Cadastrar sua chave da LunarPay', 'desc' => 'Sem ela, nenhum Pix é gerado de verdade.', 'href' => '/settings'],
    ['done' => $user['site_name'] !== 'Meu Gateway Pix', 'title' => 'Personalizar o nome do gateway', 'desc' => 'Deixe com a cara do seu negócio.', 'href' => '/settings'],
    ['done' => $totalProdutos > 0, 'title' => 'Cadastrar seu primeiro produto', 'desc' => 'Gera um link fixo pra compartilhar (WhatsApp, bio, etc.).', 'href' => '/produtos'],
    ['done' => $totalPagos > 0, 'title' => 'Receber a primeira venda', 'desc' => 'Compartilhe o link e teste um pagamento real.', 'href' => '/vendas'],
];

$weekStmt = db()->prepare("
    SELECT date(paid_at) AS dia, SUM(amount) AS total
    FROM orders
    WHERE user_id = ? AND status = 'paid' AND date(paid_at) >= date('now', '-6 days')
    GROUP BY date(paid_at)
");
$weekStmt->execute([$uid]);
$weekRows = $weekStmt->fetchAll(PDO::FETCH_KEY_PAIR);

$diasSemana = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
$week = [];
for ($i = 6; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-$i days"));
    $week[] = ['label' => $diasSemana[(int) date('w', strtotime($d))], 'date' => $d, 'total' => (float) ($weekRows[$d] ?? 0)];
}

$pctPago = $totalPedidos > 0 ? round(($totalPagos / $totalPedidos) * 100) : 0;

$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
$host   = $_SERVER['HTTP_HOST'] ?? 'localhost';
$publicCheckoutUrl = $scheme . $host . '/index.php?u=' . urlencode($user['username']);

json_out([
    'site_name'    => $user['site_name'],
    'saldo'        => $totalPago,
    'hoje_valor'   => $hojeValor,
    'hoje_vendas'  => $hojeVendas,
    'volume_mes'   => $volumeMes,
    'pendentes'    => $pendentes,
    'total_pedidos'=> $totalPedidos,
    'total_pagos'  => $totalPagos,
    'pct_pago'     => $pctPago,
    'checklist'    => $checklist,
    'week'         => $week,
    'public_checkout_url' => $publicCheckoutUrl,
    'orders'       => array_map(static fn($o) => [
        'id'             => (int) $o['id'],
        'external_id'    => $o['external_id'],
        'amount'         => (float) $o['amount'],
        'product_name'   => $o['product_name'],
        'customer_name'  => $o['customer_name'],
        'status'         => $o['status'],
        'payment_method' => $o['payment_method'],
        'created_at'     => $o['created_at'],
        'paid_at'        => $o['paid_at'],
    ], $orders),
]);
