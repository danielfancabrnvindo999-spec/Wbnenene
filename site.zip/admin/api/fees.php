<?php
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/lunarpay.php';
require_once __DIR__ . '/../../includes/json_api.php';
require_login_json();

$user = current_user();
if ($user['lunarpay_api_key'] === '') {
    json_error('Cadastre sua chave da LunarPay em Configurações primeiro.', 422);
}

$res = lunarpay_fees($user['lunarpay_api_key']);
if ($res['http_code'] < 200 || $res['http_code'] >= 300 || empty($res['data']['success'])) {
    json_error($res['data']['error'] ?? 'Não foi possível consultar as taxas na LunarPay agora.', $res['http_code'] >= 400 ? $res['http_code'] : 502);
}

json_out($res['data']);
