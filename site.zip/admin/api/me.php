<?php
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/json_api.php';
require_login_json();

$u = current_user();
json_out([
    'id'         => (int) $u['id'],
    'username'   => $u['username'],
    'site_name'  => $u['site_name'],
    'is_owner'   => current_user_is_owner(),
    'has_api_key'=> $u['lunarpay_api_key'] !== '',
    'nominal'    => $u['nominal'],
    'csrf'       => csrf_token(),
]);
