<?php
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/json_api.php';
require_login_json();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Método não permitido.', 405);
}

check_csrf_header();
$user = current_user();
$body = json_body();

$currentPass = (string) ($body['current_pass'] ?? '');
$newUsername = strtolower(trim($body['new_user'] ?? ''));
$newPass     = (string) ($body['new_pass'] ?? '');
$newPass2    = (string) ($body['new_pass2'] ?? '');

if (!password_verify($currentPass, $user['password_hash'])) {
    json_error('Senha atual incorreta.', 401);
}
if (!preg_match('/^[a-z0-9_.-]{3,30}$/', $newUsername)) {
    json_error('Usuário inválido — use só letras minúsculas, números, "-", "_" ou "." (3 a 30 caracteres).', 422);
}
if ($newPass !== '' && strlen($newPass) < 12) {
    json_error('A nova senha precisa ter pelo menos 12 caracteres.', 422);
}
if ($newPass !== $newPass2) {
    json_error('As duas senhas novas não são iguais.', 422);
}

$check = db()->prepare("SELECT COUNT(*) FROM users WHERE username = ? AND id != ?");
$check->execute([$newUsername, $user['id']]);
if ((int) $check->fetchColumn() > 0) {
    json_error('Esse usuário já está em uso por outra conta.', 409);
}

if ($newPass !== '') {
    db()->prepare("UPDATE users SET username = ?, password_hash = ? WHERE id = ?")
        ->execute([$newUsername, password_hash($newPass, PASSWORD_DEFAULT), $user['id']]);
} else {
    db()->prepare("UPDATE users SET username = ? WHERE id = ?")->execute([$newUsername, $user['id']]);
}

audit_event(current_user_id(), $newPass !== '' ? 'password_changed' : 'username_changed', current_user_id(), client_ip());
if ($newPass !== '') session_regenerate_id(true);

json_out(['ok' => true]);
