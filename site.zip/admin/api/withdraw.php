<?php
/**
 * Pedido de saque do membro. Não movimenta dinheiro aqui — só registra o
 * pedido como pendente. O dinheiro só sai de verdade quando o dono aprova
 * em admin/api/saques_admin.php (que aí sim chama a LunarPay de verdade).
 */
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/json_api.php';
require_login_json();

$uid = current_user_id();

function withdrawal_out(array $w): array
{
    return [
        'id'                     => (int) $w['id'],
        'amount'                 => (float) $w['amount'],
        'pix_key'                => $w['pix_key'],
        'pix_key_type'           => $w['pix_key_type'],
        'status'                 => $w['status'],
        'reject_reason'          => $w['reject_reason'],
        'lunarpay_withdrawal_id' => $w['lunarpay_withdrawal_id'],
        'created_at'             => $w['created_at'],
        'reviewed_at'            => $w['reviewed_at'],
    ];
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $stmt = db()->prepare("SELECT * FROM withdrawal_requests WHERE user_id = ? ORDER BY id DESC LIMIT 50");
    $stmt->execute([$uid]);
    json_out(array_map('withdrawal_out', $stmt->fetchAll(PDO::FETCH_ASSOC)));
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Método não permitido.', 405);
}

check_csrf_header();

if (rate_limit_hit('withdraw', (string) $uid, 5, 10)) {
    json_error('Muitas tentativas de saque. Aguarde alguns minutos.', 429);
}

$user = current_user();
if ($user['lunarpay_api_key'] === '') {
    json_error('Cadastre sua chave da LunarPay em Configurações primeiro.', 422);
}

$body = json_body();
$amount = (float) ($body['amount'] ?? 0);
$pixKey = trim((string) ($body['pix_key'] ?? ''));
$pixKeyType = trim((string) ($body['pix_key_type'] ?? ''));

if ($amount <= 0) {
    json_error('Informe o valor do saque.', 422);
}
if ($pixKey === '') {
    json_error('Informe a chave Pix de destino.', 422);
}
$tiposValidos = ['cpf', 'cnpj', 'email', 'phone', 'random'];
if (!in_array($pixKeyType, $tiposValidos, true)) {
    json_error('Tipo de chave Pix inválido.', 422);
}

db()->prepare("INSERT INTO withdrawal_requests (user_id, amount, pix_key, pix_key_type, status) VALUES (?, ?, ?, ?, 'pending')")
    ->execute([$uid, $amount, $pixKey, $pixKeyType]);

$id = (int) db()->lastInsertId();
audit_event($uid, 'withdraw_requested', $id, client_ip());

$stmt = db()->prepare("SELECT * FROM withdrawal_requests WHERE id = ?");
$stmt->execute([$id]);
json_out(withdrawal_out($stmt->fetch(PDO::FETCH_ASSOC)), 201);
