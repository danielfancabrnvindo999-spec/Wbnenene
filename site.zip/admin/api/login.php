<?php
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/json_api.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Método não permitido.', 405);
}

if ((int) db()->query("SELECT COUNT(*) FROM users WHERE role = 'owner'")->fetchColumn() === 0) {
    json_error('setup_required', 409);
}

$body = json_body();
$username = trim((string) ($body['username'] ?? ''));
$pass = (string) ($body['password'] ?? '');
$ip = client_ip();

if (login_is_blocked($username, $ip)) {
    json_error('Muitas tentativas erradas. Espere alguns minutos e tente novamente.', 429);
}

$stmt = db()->prepare("SELECT * FROM users WHERE username = ?");
$stmt->execute([$username]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user || (int) ($user['active'] ?? 1) !== 1 || !password_verify($pass, $user['password_hash'])) {
    login_register_failure($username, $ip);
    json_error('Usuário ou senha inválidos.', 401);
}

login_clear_failures($username, $ip);
session_regenerate_id(true);
$_SESSION['user_id'] = (int) $user['id'];
$_SESSION['last_activity'] = time();
$_SESSION['last_auth'] = time();
audit_event((int) $user['id'], 'login_success', null, $ip);

json_out(['ok' => true]);
