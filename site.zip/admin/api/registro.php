<?php
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/json_api.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Método não permitido.', 405);
}

if ((int) db()->query("SELECT COUNT(*) FROM users WHERE role = 'owner'")->fetchColumn() === 0) {
    json_error('setup_required', 409);
}

$body = json_body();
$username = strtolower(trim((string) ($body['username'] ?? '')));
$siteName = trim((string) ($body['site_name'] ?? ''));
$pass = (string) ($body['pass'] ?? '');
$pass2 = (string) ($body['pass2'] ?? '');
$ip = client_ip();

if (login_is_blocked('__registro__', $ip)) {
    json_error('Muitas tentativas. Espere alguns minutos e tente novamente.', 429);
}
if (!preg_match('/^[a-z0-9_.-]{3,30}$/', $username)) {
    login_register_failure('__registro__', $ip);
    json_error('Use de 3 a 30 letras minúsculas, números, pontos, hífens ou sublinhados.', 422);
}
if ($siteName === '') {
    login_register_failure('__registro__', $ip);
    json_error('Informe o nome do seu gateway.', 422);
}
if (strlen($pass) < 12) {
    login_register_failure('__registro__', $ip);
    json_error('A senha precisa ter pelo menos 12 caracteres.', 422);
}
if ($pass !== $pass2) {
    login_register_failure('__registro__', $ip);
    json_error('As senhas não são iguais.', 422);
}

$check = db()->prepare("SELECT COUNT(*) FROM users WHERE username = ?");
$check->execute([$username]);
if ((int) $check->fetchColumn() > 0) {
    login_register_failure('__registro__', $ip);
    json_error('Esse usuário já existe. Escolha outro.', 409);
}

db()->prepare("INSERT INTO users (username, password_hash, site_name, role) VALUES (?, ?, ?, 'user')")
    ->execute([$username, password_hash($pass, PASSWORD_DEFAULT), $siteName]);
session_regenerate_id(true);
$_SESSION['user_id'] = (int) db()->lastInsertId();

json_out(['ok' => true]);
