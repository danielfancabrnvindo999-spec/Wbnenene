<?php
/**
 * Visão consolidada do dono: soma de todos os membros, não só a própria
 * conta (esse é o dashboard.php normal, por usuário).
 */
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/json_api.php';
require_login_json();
if (!current_user_is_owner()) json_error('forbidden', 403);

$membros = db()->query("SELECT COUNT(*) total, SUM(CASE WHEN active=1 THEN 1 ELSE 0 END) active FROM users WHERE role='user'")->fetch(PDO::FETCH_ASSOC);

$totals = db()->query("
    SELECT
        SUM(CASE WHEN status = 'paid' THEN amount ELSE 0 END) AS volume_total,
        SUM(CASE WHEN status = 'paid' THEN 1 ELSE 0 END) AS vendas_total,
        SUM(CASE WHEN status = 'paid' AND date(paid_at) = date('now') THEN amount ELSE 0 END) AS volume_hoje,
        SUM(CASE WHEN status = 'paid' AND date(paid_at) = date('now') THEN 1 ELSE 0 END) AS vendas_hoje,
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pedidos_pendentes
    FROM orders
")->fetch(PDO::FETCH_ASSOC);

$saquesPendentes = (int) db()->query("SELECT COUNT(*) FROM withdrawal_requests WHERE status = 'pending'")->fetchColumn();

$weekStmt = db()->query("
    SELECT date(paid_at) AS dia, SUM(amount) AS total
    FROM orders
    WHERE status = 'paid' AND date(paid_at) >= date('now', '-6 days')
    GROUP BY date(paid_at)
");
$weekRows = $weekStmt->fetchAll(PDO::FETCH_KEY_PAIR);

$diasSemana = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
$week = [];
for ($i = 6; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-$i days"));
    $week[] = ['label' => $diasSemana[(int) date('w', strtotime($d))], 'date' => $d, 'total' => (float) ($weekRows[$d] ?? 0)];
}

$topMembros = db()->query("
    SELECT u.id, u.username, u.site_name,
        COUNT(CASE WHEN o.status = 'paid' THEN 1 END) vendas,
        COALESCE(SUM(CASE WHEN o.status = 'paid' THEN o.amount ELSE 0 END), 0) volume
    FROM users u LEFT JOIN orders o ON o.user_id = u.id
    WHERE u.role = 'user'
    GROUP BY u.id
    ORDER BY volume DESC
    LIMIT 5
")->fetchAll(PDO::FETCH_ASSOC);

json_out([
    'membros_total'     => (int) $membros['total'],
    'membros_ativos'    => (int) $membros['active'],
    'volume_total'      => (float) $totals['volume_total'],
    'vendas_total'      => (int) $totals['vendas_total'],
    'volume_hoje'       => (float) $totals['volume_hoje'],
    'vendas_hoje'       => (int) $totals['vendas_hoje'],
    'pedidos_pendentes' => (int) $totals['pedidos_pendentes'],
    'saques_pendentes'  => $saquesPendentes,
    'week'              => $week,
    'top_membros'       => array_map(static fn($m) => [
        'id'        => (int) $m['id'],
        'username'  => $m['username'],
        'site_name' => $m['site_name'],
        'vendas'    => (int) $m['vendas'],
        'volume'    => (float) $m['volume'],
    ], $topMembros),
]);
