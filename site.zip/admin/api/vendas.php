<?php
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/json_api.php';
require_login_json();

$uid = current_user_id();
$filtro = $_GET['status'] ?? 'todos';

$sql = "SELECT * FROM orders WHERE user_id = ?";
$params = [$uid];
if ($filtro === 'pago') {
    $sql .= " AND status = 'paid'";
} elseif ($filtro === 'pendente') {
    $sql .= " AND status = 'pending'";
} elseif ($filtro === 'reembolsado') {
    $sql .= " AND status = 'refunded'";
}
$sql .= " ORDER BY id DESC LIMIT 200";

$stmt = db()->prepare($sql);
$stmt->execute($params);
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

json_out(array_map(static fn($o) => [
    'id'             => (int) $o['id'],
    'external_id'    => $o['external_id'],
    'amount'         => (float) $o['amount'],
    'product_name'   => $o['product_name'],
    'customer_name'  => $o['customer_name'],
    'coupon_code'    => $o['coupon_code'],
    'status'         => $o['status'],
    'payment_method' => $o['payment_method'],
    'created_at'     => $o['created_at'],
    'paid_at'        => $o['paid_at'],
    'refunded_at'    => $o['refunded_at'],
], $orders));
