<?php
/**
 * Dono aprova ou rejeita pedidos de saque dos membros. Aprovar dispara a
 * chamada real pra LunarPay usando a Ghost Key do PRÓPRIO membro — o dono
 * nunca movimenta dinheiro da conta dele mesmo, só autoriza o pedido.
 * Nunca reprocessa um pedido já revisado (status != pending é bloqueado).
 */
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/lunarpay.php';
require_once __DIR__ . '/../../includes/json_api.php';
require_login_json();
if (!current_user_is_owner()) json_error('forbidden', 403);

function admin_withdrawal_out(array $w): array
{
    return [
        'id'                     => (int) $w['id'],
        'user_id'                => (int) $w['user_id'],
        'username'               => $w['username'],
        'site_name'              => $w['site_name'],
        'amount'                 => (float) $w['amount'],
        'pix_key'                => $w['pix_key'],
        'pix_key_type'           => $w['pix_key_type'],
        'status'                 => $w['status'],
        'reject_reason'          => $w['reject_reason'],
        'lunarpay_withdrawal_id' => $w['lunarpay_withdrawal_id'],
        'created_at'             => $w['created_at'],
        'reviewed_at'            => $w['reviewed_at'],
    ];
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $status = trim((string) ($_GET['status'] ?? 'pending'));
    $sql = "SELECT w.*, u.username, u.site_name FROM withdrawal_requests w JOIN users u ON u.id = w.user_id";
    $params = [];
    if ($status !== '' && $status !== 'all') {
        $sql .= ' WHERE w.status = ?';
        $params[] = $status;
    }
    $sql .= ' ORDER BY w.id DESC LIMIT 200';
    $stmt = db()->prepare($sql);
    $stmt->execute($params);

    $pendentes = (int) db()->query("SELECT COUNT(*) FROM withdrawal_requests WHERE status = 'pending'")->fetchColumn();

    json_out([
        'pendentes' => $pendentes,
        'saques'    => array_map('admin_withdrawal_out', $stmt->fetchAll(PDO::FETCH_ASSOC)),
    ]);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Método não permitido.', 405);
}

check_csrf_header();
$body = json_body();
$id = (int) ($body['id'] ?? 0);
$action = $body['action'] ?? '';

$stmt = db()->prepare("SELECT w.*, u.lunarpay_api_key FROM withdrawal_requests w JOIN users u ON u.id = w.user_id WHERE w.id = ?");
$stmt->execute([$id]);
$req = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$req) json_error('Pedido não encontrado.', 404);
if ($req['status'] !== 'pending') json_error('Este pedido já foi revisado.', 409);

if ($action === 'reject') {
    $reason = trim((string) ($body['reason'] ?? '')) ?: 'Rejeitado pelo administrador.';
    db()->prepare("UPDATE withdrawal_requests SET status = 'rejected', reject_reason = ?, reviewed_by = ?, reviewed_at = datetime('now') WHERE id = ?")
        ->execute([$reason, current_user_id(), $id]);
    audit_event(current_user_id(), 'withdraw_rejected', $id, client_ip());
    json_out(['ok' => true]);
}

if ($action === 'approve') {
    if ($req['lunarpay_api_key'] === '') {
        json_error('Este membro não tem chave da LunarPay cadastrada.', 422);
    }

    $externalId = 'wdr_' . bin2hex(random_bytes(8));
    $res = lunarpay_withdraw($req['lunarpay_api_key'], (float) $req['amount'], $req['pix_key'], $req['pix_key_type'], $externalId);

    if ($res['http_code'] < 200 || $res['http_code'] >= 300 || empty($res['data']['success'])) {
        db()->prepare("UPDATE withdrawal_requests SET status = 'failed', reject_reason = ?, lunarpay_response = ?, reviewed_by = ?, reviewed_at = datetime('now') WHERE id = ?")
            ->execute([$res['data']['error'] ?? 'Falha na LunarPay.', json_encode($res['data']), current_user_id(), $id]);
        audit_event(current_user_id(), 'withdraw_failed', $id, client_ip());
        json_error($res['data']['error'] ?? 'Não foi possível processar o saque na LunarPay.', $res['http_code'] >= 400 ? $res['http_code'] : 502);
    }

    db()->prepare("UPDATE withdrawal_requests SET status = 'approved', lunarpay_withdrawal_id = ?, lunarpay_response = ?, reviewed_by = ?, reviewed_at = datetime('now') WHERE id = ?")
        ->execute([$res['data']['withdrawal_id'] ?? null, json_encode($res['data']), current_user_id(), $id]);
    audit_event(current_user_id(), 'withdraw_approved', $id, client_ip());
    json_out(['ok' => true, 'lunarpay' => $res['data']]);
}

json_error('Ação inválida.', 400);
