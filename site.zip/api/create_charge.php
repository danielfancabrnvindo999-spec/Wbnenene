<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/lunarpay.php';
require_once __DIR__ . '/../includes/auth.php'; // só pra ler a sessão (Gerar Pix interno), não exige login

header('Content-Type: application/json; charset=utf-8');

$rateIdentity = substr((string) ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'), 0, 45);
if (rate_limit_hit('create_charge', $rateIdentity, 20, 10)) {
    http_response_code(429);
    echo json_encode(['error' => 'Muitas tentativas. Aguarde alguns minutos.']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true) ?: [];

$productSlug  = trim((string) ($input['product_slug'] ?? ''));
$merchant     = trim((string) ($input['merchant'] ?? ''));
$customerName = trim((string) ($input['customer_name'] ?? ''));
$productId    = null;
$owner        = null;

if ($productSlug !== '') {
    // Veio de um link de pagamento (pagar.php) — o preço é sempre lido do
    // banco aqui no servidor, nunca confiamos num valor que o navegador
    // do cliente possa ter mandado junto (evita alguém pagar menos do
    // que o produto realmente custa). O dono do gateway é o dono do produto.
    $stmt = db()->prepare("SELECT * FROM products WHERE slug = ? AND active = 1");
    $stmt->execute([$productSlug]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$product) {
        http_response_code(404);
        echo json_encode(['error' => 'Este produto não existe mais ou foi desativado.']);
        exit;
    }

    if ($product['stock'] !== null && (int) $product['stock'] <= 0) {
        http_response_code(409);
        echo json_encode(['error' => 'Este produto está esgotado no momento.']);
        exit;
    }

    $amount      = (float) $product['price'];
    $productName = $product['name'];
    $productId   = (int) $product['id'];
    $ownerId     = (int) $product['user_id'];
} elseif (preg_match('/^Bearer\s+(gwk_[a-f0-9]{48})$/', $_SERVER['HTTP_AUTHORIZATION'] ?? '', $m)) {
    // Integração externa: sistema do próprio dono do gateway chamando essa
    // API fora do navegador, autenticado pelo token gerado em Configurações
    // → API (não é a Ghost Key da LunarPay, é um token deste painel).
    $tokenStmt = db()->prepare("SELECT id FROM users WHERE api_token = ? AND active = 1");
    $tokenStmt->execute([$m[1]]);
    $ownerId = (int) $tokenStmt->fetchColumn();

    if ($ownerId === 0) {
        http_response_code(401);
        echo json_encode(['error' => 'Token de API inválido ou revogado.']);
        exit;
    }

    $amount      = (float) ($input['amount'] ?? 0);
    $productName = trim((string) ($input['product_name'] ?? 'Produto'));
} elseif (!empty($_SESSION['user_id'])) {
    // Veio do painel de admin (admin/gerar_pix.php, "Valor livre") — o
    // dono é sempre o usuário logado nesta sessão, nunca um valor mandado
    // pelo formulário.
    $amount      = (float) ($input['amount'] ?? 0);
    $productName = trim((string) ($input['product_name'] ?? 'Produto'));
    $ownerId     = (int) $_SESSION['user_id'];
} elseif ($merchant !== '') {
    // Checkout público de valor livre (index.php?u=usuario) — o cliente
    // digita o valor de propósito (cobrança avulsa, sem produto fixo).
    $merchantStmt = db()->prepare("SELECT id FROM users WHERE username = ? AND active = 1");
    $merchantStmt->execute([$merchant]);
    $ownerId = (int) $merchantStmt->fetchColumn();

    if ($ownerId === 0) {
        http_response_code(404);
        echo json_encode(['error' => 'Gateway não encontrado.']);
        exit;
    }

    $amount      = (float) ($input['amount'] ?? 0);
    $productName = trim((string) ($input['product_name'] ?? 'Produto'));
} else {
    http_response_code(400);
    echo json_encode(['error' => 'Não foi possível identificar o gateway de destino.']);
    exit;
}

$ownerStmt = db()->prepare("SELECT * FROM users WHERE id = ?");
$ownerStmt->execute([$ownerId]);
$owner = $ownerStmt->fetch(PDO::FETCH_ASSOC);

if (!$owner || (int) ($owner['active'] ?? 1) !== 1) {
    http_response_code(404);
    echo json_encode(['error' => 'Gateway não encontrado.']);
    exit;
}

// Cupom de desconto — sempre validado e aplicado aqui no servidor, nunca
// confiando num valor final que o navegador do cliente possa ter mandado.
// O código é único por dono (dois gateways diferentes podem ter o mesmo
// código sem conflito), por isso o filtro por user_id.
$couponCode = strtoupper(trim((string) ($input['coupon_code'] ?? '')));
if ($couponCode !== '') {
    $couponStmt = db()->prepare("SELECT * FROM coupons WHERE code = ? AND user_id = ? AND active = 1");
    $couponStmt->execute([$couponCode, $ownerId]);
    $coupon = $couponStmt->fetch(PDO::FETCH_ASSOC);

    if (!$coupon) {
        http_response_code(400);
        echo json_encode(['error' => 'Cupom inválido ou expirado.']);
        exit;
    }

    $amount = round($amount * (1 - ((float) $coupon['percent_off'] / 100)), 2);
} else {
    $couponCode = null;
}

if ($amount < 5) {
    http_response_code(400);
    echo json_encode(['error' => 'Valor mínimo é R$ 5,00.']);
    exit;
}

if ($owner['lunarpay_api_key'] === '') {
    http_response_code(500);
    echo json_encode(['error' => 'Este gateway ainda não foi configurado. Peça pro dono cadastrar a chave da LunarPay no painel de admin.']);
    exit;
}

$externalId  = 'ord_' . bin2hex(random_bytes(8));
try {
    $callbackUrl = application_origin() . '/webhook.php';
} catch (RuntimeException $e) {
    http_response_code(400);
    echo json_encode(['error' => 'Domínio da requisição inválido.']);
    exit;
}

$res = lunarpay_create_charge($owner['lunarpay_api_key'], $amount, $externalId, $callbackUrl);

if ($res['http_code'] !== 200 || empty($res['data']['pix_id'])) {
    http_response_code(502);
    echo json_encode([
        'error' => $res['data']['error'] ?? 'Falha ao gerar o Pix. Tente de novo em alguns segundos.',
    ]);
    exit;
}

$stmt = db()->prepare(
    "INSERT INTO orders (user_id, external_id, pix_id, amount, product_id, product_name, customer_name, coupon_code, status)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')"
);
$stmt->execute([$ownerId, $externalId, $res['data']['pix_id'], $amount, $productId, $productName, $customerName, $couponCode]);

if ($couponCode !== null) {
    db()->prepare("UPDATE coupons SET uses = uses + 1 WHERE code = ? AND user_id = ?")->execute([$couponCode, $ownerId]);
}

echo json_encode([
    'external_id' => $externalId,
    'qr_image'    => $res['data']['qr_image'],
    'pix_code'    => $res['data']['pix_code'],
    'amount'      => $amount,
]);
